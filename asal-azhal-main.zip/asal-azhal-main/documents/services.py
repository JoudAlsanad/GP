import os
from langchain_chroma import Chroma
import chromadb
import dotenv
from langchain_openai import OpenAIEmbeddings
from langchain_community.document_loaders import PyPDFLoader
from langchain.schema.document import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from documents.models import Document as DocumentModel
from langchain_google_genai import GoogleGenerativeAIEmbeddings


dotenv.load_dotenv(".env")


# utils
def get_vector_store():
    # embeddings = OpenAIEmbeddings(model="text-embedding-3-large")
    embeddings = GoogleGenerativeAIEmbeddings(model="models/text-embedding-004")

    persistent_client = chromadb.PersistentClient(path="asal_azhal_rag")

    vector_store = Chroma(
        # persist_directory="asal_azhal_rag",
        client=persistent_client,
        collection_name="asal_azhal_rag",
        embedding_function=embeddings,
    )

    return vector_store


def load_document(file_path):
    document_loader = PyPDFLoader(file_path)
    return document_loader.load()


def get_document_chunks(documents: list[Document], uuid, relative_pdf_path=""):
    # add document uuid to metadata
    for doc in documents:
        doc.metadata["uuid"] = str(uuid)
        doc.metadata["source"] = relative_pdf_path

    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=800,
        chunk_overlap=80,
        length_function=len,
        is_separator_regex=False,
    )
    chunks = text_splitter.split_documents(documents)
    chunk_ids = []
    for chunk_id, chunk in enumerate(chunks):
        chunk.metadata["id"] = f"{uuid}:{chunk_id}"
        chunk_ids.append(chunk.metadata["id"])

    return chunks, chunk_ids


def get_existing_chunk_ids():
    db = get_vector_store()
    existing_items = db.get(include=[])
    existing_ids = set(existing_items["ids"])
    return existing_ids


# services
def add_document_to_vector_store(document: DocumentModel):
    db = get_vector_store()
    pdf_path = document.pdf.path
    base_dir = "/app/asal_azhal"  # Base directory to remove from the path
    relative_pdf_path = os.path.relpath(pdf_path, base_dir)  # Get the relative path
    uuid = document.uuid
    pages = load_document(pdf_path)
    chunks, chunk_ids = get_document_chunks(pages, uuid, relative_pdf_path)
    db.add_documents(chunks, ids=chunk_ids)


def delete_document_from_vector_store(document: DocumentModel):
    db = get_vector_store()
    uuid = str(document.uuid)
    existing_ids = get_existing_chunk_ids()
    # get all the chunk_ids from existing_ids that include the uuid
    chunk_ids = [chunk_id for chunk_id in existing_ids if uuid in chunk_id]
    if len(chunk_ids) > 0:
        db.delete(ids=chunk_ids)


def update_document_in_vector_store(document: DocumentModel):
    delete_document_from_vector_store(document)
    add_document_to_vector_store(document)
