from django.urls import path, include, re_path

app_name = "documents"
urlpatterns = [
    path("api/", include("documents.api.urls")),
]
