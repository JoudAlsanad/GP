from django.db import models
from core.models import BaseModel
import uuid


# Create your models here.
class Document(BaseModel):
    title = models.CharField(max_length=255)
    pdf = models.FileField(upload_to="documents/")
    description = models.TextField(blank=True)
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    thumbnail = models.ImageField(
        upload_to="documents/thumbnails/",
        blank=True,
        null=True,
    )

    def __str__(self):
        return self.title

    def delete(self, *args, **kwargs):
        # Delete the associated files from the file system before deleting the instance
        if self.pdf:
            self.pdf.delete(save=False)
        if self.thumbnail:
            self.thumbnail.delete(save=False)

        # Now delete the actual instance from the database
        super().delete(*args, **kwargs)


class FAQ(BaseModel):
    question = models.CharField(max_length=255)
    answer = models.TextField()

    def __str__(self):
        return self.question


class Review(BaseModel):
    question = models.CharField(max_length=255)
    ai_answer = models.TextField()
    user_review = models.TextField(blank=True)  # needed only when rating is less than 3
    rating = models.IntegerField()
    user = models.ForeignKey(
        "users.User",
        on_delete=models.CASCADE,
    )  # can be an admin or a student

    def __str__(self):
        return f"{self.question} - {self.user.name}"


class EmployeeQuestion(BaseModel):
    question = models.CharField(max_length=255)
    ai_answer = models.TextField()
    employee_answer = models.TextField(blank=True)
    user = models.ForeignKey("users.User", on_delete=models.CASCADE)
    # no need to add employee as there will be only one employee
    # other employees can answer it regardless, even if there were multiple employees

    def __str__(self):
        return self.question
