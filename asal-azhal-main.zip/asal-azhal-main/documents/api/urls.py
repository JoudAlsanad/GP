from django.urls import path, include, re_path
from .views import FAQView, DocumentView, ReviewView, EmployeeQuestionView

urlpatterns = [
    # FAQView has get, post, patch, delete methods
    path("faq/", FAQView.as_view(), name="faq-list-create"),
    path("faq/<int:faq_id>/", FAQView.as_view(), name="faq-detail"),
    # DocumentView has get, post, patch, delete methods
    path("document/", DocumentView.as_view(), name="document-list-create"),
    path("document/<int:document_id>/", DocumentView.as_view(), name="document-detail"),
    # ReviewView has get, post,  delete methods
    path("review/", ReviewView.as_view(), name="review-list-create"),
    path("review/<int:review_id>/", ReviewView.as_view(), name="review-detail"),
    # EmployeeQuestionView has get, post, patch, delete methods
    path("questions/", EmployeeQuestionView.as_view(), name="question-list-create"),
    path(
        "questions/<int:question_id>/",
        EmployeeQuestionView.as_view(),
        name="question-detail",
    ),
]
