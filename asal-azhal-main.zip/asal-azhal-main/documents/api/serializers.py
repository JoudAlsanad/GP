from rest_framework import serializers
from documents.models import Document, FAQ, Review, EmployeeQuestion
from django.core.exceptions import ValidationError
from django.contrib.auth.password_validation import validate_password
from rest_framework.validators import UniqueValidator
from io import BytesIO
from django.core.files.base import ContentFile
from pdf2image import convert_from_bytes
from users.api.serializers import UserSerializer


class DocumentSerializer(serializers.ModelSerializer):
    thumbnail = serializers.SerializerMethodField()

    def create(self, validated_data):
        pdf = validated_data["pdf"]
        images = convert_from_bytes(pdf.read())
        thumbnail_image = images[0]

        # Convert the image to a format that can be saved (e.g., JPEG or PNG)
        image_io = BytesIO()  # Create an in-memory bytes buffer
        thumbnail_image.save(image_io, format="JPEG")  # Save the image in JPEG format
        image_io.seek(0)  # Go back to the start of the buffer

        # Create a ContentFile object that Django can save to the model field
        thumbnail_file = ContentFile(
            image_io.read(),
            name=f"{validated_data['title']}_thumbnail.jpg",
        )

        # add logic to generate embeddings for document

        doc = Document.objects.create(
            title=validated_data["title"],
            pdf=validated_data["pdf"],
            description=validated_data.get("description", ""),
            thumbnail=thumbnail_file,  # Save the thumbnail to the ImageField
        )

        return doc

    def update(self, instance, validated_data):
        # Delete the old PDF if a new one is being uploaded
        if "pdf" in validated_data:
            if instance.pdf:
                instance.pdf.delete(
                    save=False
                )  # Delete old PDF file from the file system
                instance.thumbnail.delete(save=False)

            pdf = validated_data["pdf"]

            # Convert the first page of the PDF to an image
            images = convert_from_bytes(pdf.read(), first_page=1, last_page=1)
            thumbnail_image = images[0]  # Get the first page

            # Convert the image to a format that can be saved (e.g., JPEG or PNG)
            image_io = BytesIO()  # Create an in-memory bytes buffer
            thumbnail_image.save(
                image_io, format="JPEG"
            )  # Save the image in JPEG format
            image_io.seek(0)  # Go back to the start of the buffer

            # Create a ContentFile object that Django can save to the model field
            thumbnail_file = ContentFile(
                image_io.read(),
                name=f"{validated_data.get('title', instance.title)}_thumbnail.jpg",
            )

            # Set the new thumbnail
            instance.thumbnail.save(thumbnail_file.name, thumbnail_file, save=False)

        # Update other fields
        instance.title = validated_data.get("title", instance.title)
        instance.description = validated_data.get("description", instance.description)
        instance.pdf = validated_data.get("pdf", instance.pdf)

        # Save the instance
        instance.save()
        return instance

    def get_thumbnail(self, obj):
        request = self.context.get("request")
        if obj.thumbnail and request:
            return request.build_absolute_uri(obj.thumbnail.url)
        return None

    class Meta:
        model = Document
        fields = ["id", "title", "pdf", "description", "thumbnail"]


class FAQSerializer(serializers.ModelSerializer):
    class Meta:
        model = FAQ
        fields = "__all__"


class ReviewSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = Review
        fields = "__all__"

    def validate(self, data):
        # Ensure that user_review is provided if the rating is less than 3
        if data["rating"] < 3 and not data.get("user_review"):
            raise serializers.ValidationError(
                "User review is required for ratings less than 3."
            )
        return data


class EmployeeQuestionSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = EmployeeQuestion
        fields = "__all__"


class EmployeeAnswerUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeQuestion
        fields = ["employee_answer"]  # Employee can only patch this field
