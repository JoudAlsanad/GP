from django.contrib.auth import authenticate
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.authtoken.models import Token
from core.auth.permissions import (
    IsEmployee,
    IsSchoolAdmin,
    IsStudent,
    IsGuest,
    IsStudentOrGuest,
)
from core.views import BaseAPIView
from documents.models import Document, FAQ, Review, EmployeeQuestion
from .serializers import (
    DocumentSerializer,
    FAQSerializer,
    ReviewSerializer,
    EmployeeQuestionSerializer,
    EmployeeAnswerUpdateSerializer,
)
from documents.services import (
    delete_document_from_vector_store,
    add_document_to_vector_store,
    update_document_in_vector_store,
)


class DocumentView(BaseAPIView):
    permission_classes = [IsSchoolAdmin]
    serializer_class = DocumentSerializer

    def get(self, request, document_id=None):
        if document_id:
            try:
                document = Document.objects.get(id=document_id)
                serializer = DocumentSerializer(document, context={"request": request})
                return self.send_success_response(payload=serializer.data)
            except Document.DoesNotExist:
                return self.send_not_found_response(message="Document not found")
        else:
            documents = Document.objects.all()
            serializer = DocumentSerializer(
                documents, many=True, context={"request": request}
            )
            return self.send_success_response(payload=serializer.data)

    def post(self, request):
        data = request.data
        serializer = DocumentSerializer(data=data, context={"request": request})
        if serializer.is_valid(raise_exception=True):
            document = serializer.save()
            add_document_to_vector_store(document)
            return self.send_success_response(
                payload=serializer.data,
                message="Document created successfully",
            )
        return self.send_error_response(serializer.errors)

    def patch(self, request, document_id):
        try:
            document = Document.objects.get(id=document_id)
        except Document.DoesNotExist:
            return self.send_not_found_response(message="Document not found")
        data = request.data
        serializer = DocumentSerializer(
            document, data=data, partial=True, context={"request": request}
        )
        if serializer.is_valid(raise_exception=True):
            updated_document = serializer.save()
            update_document_in_vector_store(updated_document)
            return self.send_success_response(
                payload=serializer.data,
                message="Document updated successfully",
            )
        return self.send_bad_request_response(serializer.errors)

    def delete(self, request, document_id):
        try:
            document = Document.objects.get(id=document_id)
            delete_document_from_vector_store(document)
            document.delete()
            return self.send_success_response(message="Document deleted successfully")
        except Document.DoesNotExist:
            return self.send_not_found_response(message="Document not found")


class FAQView(BaseAPIView):
    serializer_class = FAQSerializer
    # permission_classes = [IsStudent]

    def get_permissions(self):
        if self.request.method == "GET":
            return []
        return [IsSchoolAdmin()]

    def get(self, request, faq_id=None):
        if faq_id:
            try:
                faq = FAQ.objects.get(id=faq_id)
                serializer = FAQSerializer(faq)
                return self.send_success_response(payload=serializer.data)
            except FAQ.DoesNotExist:
                return self.send_not_found_response(message="FAQ not found")
        else:
            # return the latest 5 FAQs
            faqs = FAQ.objects.all().order_by("-created_at")[:5]
            serializer = FAQSerializer(faqs, many=True)
            return self.send_success_response(payload=serializer.data)

    def post(self, request):
        n_faqs = FAQ.objects.count()
        if n_faqs >= 5:
            return self.send_bad_request_response(
                message="Only 5 FAQs are allowed at a time."
            )
        data = request.data
        serializer = FAQSerializer(data=data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return self.send_success_response(
                payload=serializer.data,
                message="FAQ created successfully",
            )
        return self.send_bad_request_response(serializer.errors)

    def patch(self, request, faq_id):
        faq = FAQ.objects.get(id=faq_id)
        data = request.data
        serializer = FAQSerializer(faq, data=data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return self.send_success_response(
                payload=serializer.data,
                message="FAQ updated successfully",
            )
        return self.send_bad_request_response(serializer.errors)

    def delete(self, request, faq_id):
        try:
            faq = FAQ.objects.get(id=faq_id)
            faq.delete()
            return self.send_success_response(message="FAQ deleted successfully")
        except FAQ.DoesNotExist:
            return self.send_not_found_response(message="FAQ not found")


class ReviewView(BaseAPIView):
    serializer_class = ReviewSerializer

    def get_permissions(self):
        if self.request.method == "POST":
            return [IsStudentOrGuest()]
        return [IsSchoolAdmin()]

    def get(self, request, review_id=None):
        if review_id:
            try:
                review = Review.objects.get(id=review_id)
                serializer = ReviewSerializer(review)
                return self.send_success_response(payload=serializer.data)
            except Review.DoesNotExist:
                return self.send_not_found_response(message="Review not found")
        else:
            reviews = Review.objects.all()
            serializer = ReviewSerializer(reviews, many=True)
            return self.send_success_response(payload=serializer.data)

    def post(self, request):
        data = request.data
        serializer = ReviewSerializer(data=data)
        if serializer.is_valid(raise_exception=True):
            serializer.save(user=request.user)
            return self.send_success_response(
                payload=serializer.data,
                message="Review created successfully",
            )
        return self.send_bad_request_response(serializer.errors)

    def delete(self, request, review_id):
        try:
            review = Review.objects.get(id=review_id)
            review.delete()
            return self.send_success_response(message="Review deleted successfully")
        except Review.DoesNotExist:
            return self.send_not_found_response(message="Review not found")


class EmployeeQuestionView(BaseAPIView):
    serializer_class = EmployeeQuestionSerializer

    def get_permissions(self):
        if self.request.method in ["POST", "DELETE"]:
            return [IsStudentOrGuest()]
        if self.request.method == "PATCH":
            return [IsEmployee()]
        if self.request.method in ["GET"]:
            return [IsAuthenticated()]

        return [IsSchoolAdmin()]

    def get(self, request, question_id=None):
        """
        GET:
        - All users (students, employees, admin) can view employee questions.
        - If `question_id` is provided, fetch a single question; otherwise, fetch all.
        """
        user = request.user
        if question_id:
            try:
                question = EmployeeQuestion.objects.get(id=question_id)
                if question.user != user and not (
                    user.is_school_admin or user.is_employee
                ):
                    return self.send_unauthorized_response(
                        message="You don't have permission to view this question"
                    )
                serializer = EmployeeQuestionSerializer(question)
                return self.send_success_response(payload=serializer.data)
            except EmployeeQuestion.DoesNotExist:
                return self.send_not_found_response(message="Question not found")
        else:
            if user.is_student or user.is_guest:
                questions = EmployeeQuestion.objects.filter(user=user)
            else:
                questions = EmployeeQuestion.objects.all()
            serializer = EmployeeQuestionSerializer(questions, many=True)
            return self.send_success_response(payload=serializer.data)

    def post(self, request):
        """
        POST:
        - Only students can create a new employee question.
        """
        data = request.data
        serializer = EmployeeQuestionSerializer(data=data)
        if serializer.is_valid(raise_exception=True):
            serializer.save(user=request.user)
            return self.send_success_response(
                payload=serializer.data,
                message="Question sent to employee successfully",
            )
        return self.send_bad_request_response(serializer.errors)

    def patch(self, request, question_id):
        """
        PATCH:
        - Only employees can edit the `employee_answer` field.
        """
        try:
            question = EmployeeQuestion.objects.get(id=question_id)
        except EmployeeQuestion.DoesNotExist:
            return self.send_not_found_response(message="Question not found")

        # Allow employee to patch only the `employee_answer` field
        serializer = EmployeeAnswerUpdateSerializer(
            question, data=request.data, partial=True
        )
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return self.send_success_response(
                payload=serializer.data,
                message="Employee answer updated successfully",
            )
        return self.send_bad_request_response(serializer.errors)

    def delete(self, request, question_id):
        """
        DELETE:
        - Only students can delete a question.
        """
        try:
            question = EmployeeQuestion.objects.get(id=question_id)
            if request.user == question.user:
                question.delete()
                return self.send_success_response(
                    message="Employee question deleted successfully"
                )
            return self.send_unauthorized_response(
                message="You don't have permission to delete this question"
            )
        except EmployeeQuestion.DoesNotExist:
            return self.send_not_found_response(message="Question not found")
