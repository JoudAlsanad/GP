from django.contrib import admin
from documents.models import Document, FAQ, Review, EmployeeQuestion

# Register your models here.
admin.site.register(Document)
admin.site.register(FAQ)
admin.site.register(Review)
admin.site.register(EmployeeQuestion)
