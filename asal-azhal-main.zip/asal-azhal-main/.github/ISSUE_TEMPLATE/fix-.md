---
name: 'Fix '
about: Bug report
title: "[BUG] - "
labels: bug
assignees: ''

---

- [ ] Frontend
- [x] Backend

**Bug/Fix**

**Screenshots**
Copy and paste the screenshot if applicable
