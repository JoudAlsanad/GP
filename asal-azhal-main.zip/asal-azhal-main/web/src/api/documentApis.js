import axiosInstance from './config';

export const getDocuments = async () => {
    try {
        const response = await axiosInstance.get('/documents/api/document/');
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to fetch documents');
    }
};

export const downloadPdf = async (pdfUrl, title) => {
    try {
        const response = await axiosInstance.get(pdfUrl, {
            responseType: 'blob'
        });
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `${title}.pdf`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to download pdf');
    }
};

export const deleteDocument = async (id) => {
    try {
        const response = await axiosInstance.delete(`/documents/api/document/${id}/`);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to delete document');
    }
};

export const postDocument = async (data) => {
    try {
        const response = await axiosInstance.post('/documents/api/document/', data, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to add new document');
    }
};

export const patchDocument = async (data, id) => {
    try {
        const response = await axiosInstance.patch(`/documents/api/document/${id}/`, data, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to edit document');
    }
};
