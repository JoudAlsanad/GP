import axiosInstance from './config';

export const login = async (email, password) => {
    try {
        const response = await axiosInstance.post('/users/api/login', {
            email,
            password
        });
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Login failed');
    }
};

export const guestLogin = async (name) => {
    try {
        const response = await axiosInstance.post('/users/api/guest_login/', {
            name: name
        });
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Login failed');
    }
};

export const fetchUserProfile = async () => {
    try {
        const response = await axiosInstance.get('/users/api/profile');
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to fetch user profile');
    }
};

export const patchUserProfile = async (data) => {
    try {
        const response = await axiosInstance.patch('/users/api/profile', data);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to update user profile');
    }
};

export const signup = async (data) => {
    try {
        const response = await axiosInstance.post('/users/api/signup', {
            name: data.name,
            email: data.email,
            password: data.password,
            confirm_password: data.confirmPassword
        });
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Signup failed');
    }
};

export const googleLogin = async (data) => {
    try {
        const response = await axiosInstance.post('/users/api/google_login/', data);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Signup failed');
    }
};

export const deleteUser = async () => {
    try {
        const response = await axiosInstance.post('/users/api/delete_user');
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to delete user');
    }
};

export const setPassword = async (data) => {
    try {
        const response = await axiosInstance.post('/users/api/set_password', {
            password1: data.password1,
            token: data.token,
            password2: data.password2
        });
        return response.data;
    } catch (error) {
        throw new Error(error?.message || 'Failed to set password');
    }
};

export const forgotPassword = async (email) => {
    try {
        const response = await axiosInstance.post('/users/api/forgot_password', {
            email
        });
        return response.data;
    } catch (error) {
        throw new Error(error?.message || 'Failed to send reset password link');
    }
};
