import axiosInstance from './config';

export async function getLastConversation() {
    try {
        const response = await axiosInstance.get('/chat/api/conversations/last/');
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to get last conversation');
    }
}

export async function sendMessage(message, chatId) {
    try {
        const response = await axiosInstance.post(`/chat/api/conversations/${chatId}/chat/`, {
            question: message
        });
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to send message');
    }
}

export async function clearChat(chatId) {
    try {
        const response = await axiosInstance.post(`/chat/api/conversations/${chatId}/clear/`);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to clear chat');
    }
}

export async function downloadReference(ref) {
    try {
        const response = await axiosInstance.post(ref);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to downlod reference');
    }
}
