import axiosInstance from './config';

export const getReviews = async () => {
    try {
        const response = await axiosInstance.get('/documents/api/review/');
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to get reviews');
    }
};

export const postReview = async (data) => {
    try {
        const response = await axiosInstance.post('/documents/api/review/', data);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to post review');
    }
};
