import axiosInstance from './config';

export const getFaqs = async () => {
    try {
        const response = await axiosInstance.get('/documents/api/faq/');
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to get faqs');
    }
};

export const patchFaq = async (id, data) => {
    try {
        const response = await axiosInstance.patch(`/documents/api/faq/${id}/`, data);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to patch faq');
    }
};

export const postFaq = async (data) => {
    try {
        const response = await axiosInstance.post('/documents/api/faq/', data);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to post faq');
    }
};

export const delFaq = async (id) => {
    try {
        const response = await axiosInstance.delete(`/documents/api/faq/${id}/`);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to delete faq');
    }
};
