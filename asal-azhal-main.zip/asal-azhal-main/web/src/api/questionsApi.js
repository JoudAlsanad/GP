import axiosInstance from './config';

export async function getQuestions() {
    try {
        const response = await axiosInstance.get('/documents/api/questions/');
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to get questions');
    }
}

export async function patchQuestion(id, data) {
    try {
        const response = await axiosInstance.patch(`/documents/api/questions/${id}/`, data);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to patch question');
    }
}

export async function deleteQuestion(id) {
    try {
        const response = await axiosInstance.delete(`/documents/api/questions/${id}/`);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to delete question');
    }
}

export async function postQuestion(data) {
    try {
        const response = await axiosInstance.post('/documents/api/questions/', data);
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Failed to post question');
    }
}
