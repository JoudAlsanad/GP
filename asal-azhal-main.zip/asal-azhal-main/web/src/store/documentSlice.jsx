import { createSlice } from '@reduxjs/toolkit';
import { deleteDocument, getDocuments, patchDocument, postDocument } from '../api/documentApis.js';

const initialState = {
    documents: null,
    loading: false,
    error: null
};

const documentSlice = createSlice({
    name: 'doc',
    initialState,
    reducers: {
        setDocuments: (state, action) => {
            state.documents = action.payload;
        },
        setLoading: (state, action) => {
            state.loading = action.payload;
        },
        setError: (state, action) => {
            state.error = action.payload;
        },
        clearError: (state) => {
            state.error = null;
        }
    }
});

export const { setLoading, setError, clearError, setDocuments } = documentSlice.actions;

// Async thunk action to handle login
export const getDocs = () => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const documents = await getDocuments();
        dispatch(setDocuments(documents));
        return documents;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const deleteDoc = (id) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const response = await deleteDocument(id);
        dispatch(getDocs());
        return response;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const addDoc = (data) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const response = await postDocument(data);
        dispatch(getDocs());
        return response;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const editDoc = (data, id) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const response = await patchDocument(data, id);
        dispatch(getDocs());
        return response;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export default documentSlice.reducer;
