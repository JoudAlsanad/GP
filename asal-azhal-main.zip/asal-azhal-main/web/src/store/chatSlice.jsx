import { createSlice } from '@reduxjs/toolkit';
import { clearChat, getLastConversation, sendMessage } from '../api/chatApi.js';

const initialState = {
    conversation: null,
    messages: [],
    loading: false,
    error: null
};

const chatSlice = createSlice({
    name: 'chat',
    initialState,
    reducers: {
        setConversation: (state, action) => {
            state.conversation = action.payload;
        },
        setMessages: (state, action) => {
            state.messages = action.payload;
        },
        setLoading: (state, action) => {
            state.loading = action.payload;
        },
        setError: (state, action) => {
            state.error = action.payload;
        },
        clearError: (state) => {
            state.error = null;
        }
    }
});

export const { setLoading, setError, clearError, setConversation, setMessages } = chatSlice.actions;

// Async thunk action to handle login
export const getLastConvo = () => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const convo = await getLastConversation();
        dispatch(setConversation(convo.data.conversation));
        dispatch(setMessages(convo.data.messages));
        return convo.data;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const askQuestion = (chatId, message) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const convo = await sendMessage(message, chatId);
        dispatch(setConversation(convo.data.conversation));
        dispatch(setMessages(convo.data.messages));
        return convo.data;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const clearConversation = (chatId) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const convo = await clearChat(chatId);
        dispatch(setConversation(null));
        dispatch(setMessages([]));
        return convo.data;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export default chatSlice.reducer;
