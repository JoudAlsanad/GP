import { createSlice } from '@reduxjs/toolkit';
import { getFaqs, patchFaq, postFaq, delFaq } from '../api/faqApi.js';

const initialState = {
    faqs: null,
    loading: false,
    error: null
};

const faqSlice = createSlice({
    name: 'faq',
    initialState,
    reducers: {
        setFaqs: (state, action) => {
            state.faqs = action.payload;
        },
        setLoading: (state, action) => {
            state.loading = action.payload;
        },
        setError: (state, action) => {
            state.error = action.payload;
        },
        clearError: (state) => {
            state.error = null;
        }
    }
});

export const { setLoading, setError, clearError, setFaqs } = faqSlice.actions;

export const fetchFaqs = () => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const faqs = await getFaqs();
        dispatch(setFaqs(faqs.data));
        return faqs;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const editFaq = (id, data) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const faqs = await patchFaq(id, data);
        dispatch(fetchFaqs());
        return faqs;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const addNewFaq = (data) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const faqs = await postFaq(data);
        dispatch(fetchFaqs());
        return faqs;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const deleteFaq = (id) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        await delFaq(id);
        dispatch(fetchFaqs());
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export default faqSlice.reducer;
