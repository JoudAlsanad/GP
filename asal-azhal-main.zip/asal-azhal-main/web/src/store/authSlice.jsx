import { createSlice } from '@reduxjs/toolkit';
import {
    login,
    fetchUserProfile,
    patchUserProfile,
    signup,
    guestLogin,
    googleLogin,
    deleteUser,
    setPassword,
    forgotPassword
} from '../api/authApi.js';

const initialState = {
    user: null,
    userProfile: null,
    isLoggedIn: null,
    loading: false,
    error: null
};

const authSlice = createSlice({
    name: 'auth',
    initialState,
    reducers: {
        setUserProfile: (state, action) => {
            console.log('Setting user profile', action.payload);
            state.userProfile = action.payload;
            state.isLoggedIn = !!action.payload;
        },
        setLoading: (state, action) => {
            state.loading = action.payload;
        },
        setError: (state, action) => {
            state.error = action.payload;
        },
        clearError: (state) => {
            state.error = null;
        }
    }
});

export const { setLoading, setError, clearError, setUserProfile } = authSlice.actions;

// Async thunk action to handle login
export const loginUser = (email, password) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const userData = await login(email, password);
        // Optionally, store token in localStorage or Redux state
        localStorage.setItem('token', userData?.data?.token);
        localStorage.setItem('userType', userData?.data?.user_type);
        dispatch(getUserProfile());
        return userData;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const loginGuest = (name) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const userData = await guestLogin(name);
        // dispatch(getUserProfile());
        // Optionally, store token in localStorage or Redux state
        localStorage.setItem('token', userData?.data?.token);
        localStorage.setItem('userType', userData?.data?.user_type);
        return userData;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const getUserProfile = () => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        // Fetch user profile data
        const userData = await fetchUserProfile();
        dispatch(setUserProfile(userData?.data?.user));
        localStorage.setItem('userType', userData?.data?.user?.user_type);
        return userData;
    } catch (error) {
        dispatch(setError(error.message));
        dispatch(setUserProfile(null));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const signupUser = (data) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const userData = await signup(data);
        // Optionally, store token in localStorage or Redux state
        localStorage.setItem('token', userData?.data?.token);
        localStorage.setItem('userType', userData?.data?.user_type);
        await dispatch(getUserProfile());
        return userData;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const logoutUser = () => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        // Clear user data from state
        dispatch(setUserProfile(null));
        // Clear token from localStorage
        localStorage.removeItem('token');
        localStorage.removeItem('userType');
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const updateUserProfile = (data) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const userData = await patchUserProfile(data);
        dispatch(getUserProfile());
        return userData;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const googleLoginUser = (data) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const userData = await googleLogin(data);
        // Optionally, store token in localStorage or Redux state
        localStorage.setItem('token', userData?.key);
        const completeUserData = await fetchUserProfile();
        console.log('Complete user data', completeUserData);
        await dispatch(setUserProfile(completeUserData?.data?.user));
        localStorage.setItem('userType', completeUserData?.data?.user?.user_type);
        return completeUserData;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const deleteUserAccount = () => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const userData = await deleteUser();
        await dispatch(setUserProfile(null));
        localStorage.removeItem('token');
        localStorage.removeItem('userType');
        return userData;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const setPasswordAsync = (data) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        // Call the API to set the password
        await dispatch(logoutUser());
        const userData = await setPassword(data);
        await dispatch(setUserProfile(userData?.data));
        localStorage.setItem('token', userData?.data?.token);
        localStorage.setItem('userType', userData?.data?.user_type);
        await dispatch(getUserProfile());
        // Optionally, store token in localStorage or Redux state
        return userData;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const forgotPasswordAsync = (data) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const userData = await forgotPassword(data);
        return userData;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export default authSlice.reducer;
