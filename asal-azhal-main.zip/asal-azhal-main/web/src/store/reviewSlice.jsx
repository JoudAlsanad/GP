import { createSlice } from '@reduxjs/toolkit';
import { getReviews, postReview } from '../api/reviewApi';

const initialState = {
    reviews: [],
    loading: false,
    error: null
};

const reviewSlice = createSlice({
    name: 'review',
    initialState,
    reducers: {
        setReviews: (state, action) => {
            state.reviews = action.payload;
        },
        setLoading: (state, action) => {
            state.loading = action.payload;
        },
        setError: (state, action) => {
            state.error = action.payload;
        },
        clearError: (state) => {
            state.error = null;
        }
    }
});

export const { setLoading, setError, clearError, setReviews } = reviewSlice.actions;

export const fetchReviews = () => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const reviews = await getReviews();
        dispatch(setReviews(reviews.data));
        return reviews;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const addNewReview = (data) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const reviews = await postReview(data);
        dispatch(setReviews(reviews.data));
        return reviews;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export default reviewSlice.reducer;
