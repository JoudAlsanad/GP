import { configureStore } from '@reduxjs/toolkit';

import authReducer from './authSlice.jsx';
import docReducer from './documentSlice.jsx';
import faqReducer from './faqSlice.jsx';
import reviewReducer from './reviewSlice.jsx';
import questionsReducer from './questionsSlice.jsx';
import chatReducer from './chatSlice.jsx';

export default configureStore({
    reducer: {
        auth: authReducer,
        doc: docReducer,
        faq: faqReducer,
        review: reviewReducer,
        question: questionsReducer,
        chat: chatReducer
        // Add other reducers here
    }
});
