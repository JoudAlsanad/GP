import { createSlice } from '@reduxjs/toolkit';
import { deleteQuestion, getQuestions, patchQuestion, postQuestion } from '../api/questionsApi.js';

const initialState = {
    questions: [],
    loading: false,
    error: null
};

const questionsSlice = createSlice({
    name: 'question',
    initialState,
    reducers: {
        setQuestions: (state, action) => {
            state.questions = action.payload;
        },
        setLoading: (state, action) => {
            state.loading = action.payload;
        },
        setError: (state, action) => {
            state.error = action.payload;
        },
        clearError: (state) => {
            state.error = null;
        }
    }
});

export const { setLoading, setError, clearError, setQuestions } = questionsSlice.actions;

export const fetchQuestions = () => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const questions = await getQuestions();
        dispatch(setQuestions(questions.data));
        return questions;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const updateQuestion = (id, data) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const questions = await patchQuestion(id, data);
        dispatch(fetchQuestions());
        return questions;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const delQuestion = (id) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const response = await deleteQuestion(id);
        dispatch(fetchQuestions());
        return response;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export const addNewQuestion = (data) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const response = await postQuestion(data);
        // dispatch(fetchQuestions());
        return response;
    } catch (error) {
        dispatch(setError(error.message));
        throw error;
    } finally {
        dispatch(setLoading(false));
    }
};

export default questionsSlice.reducer;
