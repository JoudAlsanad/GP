import { Outlet } from 'react-router-dom';
import './App.css';

function App() {
    return (
        <>
            <div className="fixed bottom-0 left-0 right-0 top-0 z-[200] flex items-center justify-center bg-[rgba(0,0,0,0.5)]">
                <div className="loader"></div>
            </div>
            <Outlet />
        </>
    );
}

export default App;
