import { useEffect } from 'react';
import UserIcon from '../../components/icons/UserIcon';
import { getUserProfile } from '../../store/authSlice';
import { useDispatch, useSelector } from 'react-redux';
import DashboardLayout from '../../components/dashboard/layout';
import ChatIcon from '../../components/icons/ChatIcon';

export default function GuestDashboard() {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(getUserProfile());
    }, [dispatch]);

    const userProfile = useSelector((state) => state.auth.userProfile);
    const list = [
        {
            name: 'الملف الشخصي',
            icon: <UserIcon />,
            link: '/profile'
        },
        {
            name: 'بدء محادثة',
            icon: <ChatIcon />,
            link: '/guest/chat'
        }
    ];
    return (
        <>
            <div className="flex h-full w-full items-center justify-center">
                {userProfile && (
                    <DashboardLayout title={`اهلًا ${userProfile.name} !`} listOfIcons={list} />
                )}
            </div>
        </>
    );
}
