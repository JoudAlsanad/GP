import { useNavigate } from 'react-router-dom';
import Button from '../../../components/buttons/buttons';
import { useDispatch } from 'react-redux';
import toast from 'react-hot-toast';
import { useForm } from 'react-hook-form';
import { useQuery } from '../../../hooks/useQuery';
import { useRef } from 'react';
import { ChevronLeftIcon } from '@heroicons/react/24/solid';
import { setPasswordAsync } from '../../../store/authSlice';

export default function SetPassword() {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    let query = useQuery();

    const btnRef = useRef();

    const handleSetPassword = (e) => {
        e.preventDefault();
        console.log('submitting form');
        btnRef.current.click();
    };

    const {
        register,
        handleSubmit,
        watch,
        formState: { errors }
    } = useForm();

    const submitForm = (data) => {
        const { password1, password2 } = data;
        const token = query.get('token');
        console.log(token);

        if (!token) {
            toast.error('رابط إعادة تعيين كلمة المرور غير صالح');
            return;
        }

        if (password1.length < 8) {
            toast.error('يجب أن تحتوي كلمة المرور على 8 أحرف على الأقل');
            return;
        }

        if (password1 !== password2) {
            toast.error('كلمات المرور غير متطابقة');
            return;
        }

        dispatch(setPasswordAsync({ password1, password2, token }))
            .then(() => {
                toast.success('تم تحديث كلمة المرور بنجاح');
                navigate('/login'); // Redirect to login page after successful password set
            })
            .catch((error) => {
                toast.error(error.message);
            });
    };

    return (
        <div className="flex h-full w-full items-center justify-center">
            <div className="rounded-4xl bg-transBg flex w-1/2 flex-col gap-10 p-12">
                <div className="flex items-center justify-between">
                    <ChevronLeftIcon
                        className="h-8 w-8 cursor-pointer"
                        onClick={() => navigate('/')}
                    />
                    <p className="text-3xl font-bold">تعيين كلمة المرور</p>
                </div>
                <form onSubmit={handleSubmit(submitForm)} className="flex flex-col gap-5">
                    <fieldset className="flex w-full flex-col gap-2 text-right">
                        <label htmlFor="password" className="text-lg">
                            كلمة المرور الجديدة
                        </label>
                        <input
                            {...register('password1', {
                                required: { value: true, message: 'كلمة المرور مطلوبة' },
                                pattern: {
                                    value: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
                                    message:
                                        'يجب أن تحتوي كلمة المرور على حرف خاص واحد وحرف كبير ورقم واحد'
                                }
                            })}
                            placeholder="كلمة المرور الجديدة"
                            type="password"
                            id="password"
                            dir="rtl"
                            className="w-full rounded-lg border-none bg-white px-2 py-2 text-right"
                        />
                        {errors.password && (
                            <span className="text-sm italic text-red-600">
                                {errors.password?.message}
                            </span>
                        )}
                    </fieldset>
                    <fieldset className="flex w-full flex-col gap-2 text-right">
                        <label htmlFor="confirmPassword" className="text-lg">
                            تأكيد كلمة المرور
                        </label>
                        <input
                            {...register('password2', {
                                required: { value: true, message: 'تأكيد كلمة المرور مطلوب' },
                                validate: (value) =>
                                    value === watch('password') || 'كلمات المرور غير متطابقة'
                            })}
                            placeholder="تأكيد كلمة المرور"
                            type="password"
                            id="confirmPassword"
                            dir="rtl"
                            className="w-full rounded-lg border-none bg-white px-2 py-2 text-right"
                        />
                        {errors.confirmPassword && (
                            <span className="text-sm italic text-red-600">
                                {errors.confirmPassword?.message}
                            </span>
                        )}
                    </fieldset>
                    {/* <button type="submit" ref={btnRef} onClick={handleSetPassword} hidden></button> */}
                    <Button
                        text={'تعيين كلمة المرور'}
                        onClick={() => {
                            submitForm({
                                password1: watch('password1'),
                                password2: watch('password2')
                            });
                        }}
                        className="mt-5"
                    />
                </form>
            </div>
        </div>
    );
}
