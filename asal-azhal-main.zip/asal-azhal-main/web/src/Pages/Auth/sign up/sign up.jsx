import { useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../../../components/buttons/buttons';
import { useDispatch } from 'react-redux';
import { signupUser, googleLoginUser } from '../../../store/authSlice';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { useGoogleLogin } from '@react-oauth/google';
import { FcGoogle } from 'react-icons/fc';
import { ChevronLeftIcon } from '@heroicons/react/24/solid';

export default function SignUp() {
    const btnRef = useRef();
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const {
        register,
        handleSubmit,
        watch,
        formState: { errors }
    } = useForm();

    const submitForm = (data) => {
        const { name, email, password, confirmPassword } = data;

        dispatch(signupUser({ name, email, password, confirmPassword }))
            .then(() => {
                toast.success('تم تسجيل الحساب بنجاح');
                navigate('/registered');
            })
            .catch((error) => {
                toast.error(error.message);
            });
    };

    const signUp = (e) => {
        e.preventDefault();
        btnRef.current.click();
    };

    const googleLogin = useGoogleLogin({
        onSuccess: (token) => {
            console.log(token);
            const payload = {
                access_token: token.access_token
            };
            console.log(payload);
            dispatch(googleLoginUser(payload))
                .then((data) => {
                    console.log('Google Login Data:', data);
                    toast.success('تم تسجيل الدخول بنجاح');
                    const userType = data?.data?.user_type;
                    console.log(userType);
                    navigate('/student');
                })
                .catch(() => {
                    toast.error('Login failed');
                });
        }
    });

    const handleGoogleLogin = (e) => {
        e.preventDefault();
        googleLogin();
    };

    return (
        <>
            <div className="flex h-full w-full grow-0 items-center justify-center py-10">
                <div className="rounded-4xl bg-transBg flex w-1/2 flex-col gap-10 p-12">
                    <div className="flex items-center justify-between">
                        <ChevronLeftIcon
                            className="h-8 w-8 cursor-pointer"
                            onClick={() => navigate('/')}
                        />
                        <p className="text-3xl font-bold">تسجيل</p>
                    </div>
                    <form onSubmit={handleSubmit(submitForm)} className="flex flex-col gap-5">
                        <fieldset className="flex w-full flex-col gap-2 text-right">
                            <label htmlFor="name" className="text-lg">
                                الاسم
                            </label>
                            <input
                                {...register('name', {
                                    required: { value: true, message: 'الاسم مطلوب' }
                                })}
                                placeholder="سارة"
                                type="name"
                                name="name"
                                id="name"
                                dir="rtl"
                                className="w-full rounded-lg border-none bg-white px-2 py-2 text-right"
                            />
                            {errors.name && (
                                <span className="text-sm italic text-red-600">
                                    {errors.name?.message}
                                </span>
                            )}
                        </fieldset>
                        <fieldset className="flex w-full flex-col gap-2 text-right">
                            <label htmlFor="email" className="text-lg">
                                ادخل البريد الالكتروني
                            </label>
                            <input
                                {...register('email', {
                                    required: {
                                        value: true,
                                        message: 'البريد الإلكتروني مطلوب'
                                    },
                                    pattern: {
                                        value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
                                        message: 'Please enter a valid email'
                                    }
                                })}
                                placeholder="email@student.ksu.edu.sa"
                                type="email"
                                name="email"
                                id="email"
                                dir="rtl"
                                className="w-full rounded-lg border-none bg-white px-2 py-2 text-right"
                            />
                            {errors.email && (
                                <span className="text-sm italic text-red-600">
                                    {errors.email?.message}
                                </span>
                            )}
                        </fieldset>
                        <fieldset className="flex w-full flex-col gap-2 text-right">
                            <label htmlFor="password" className="text-lg">
                                ادخل كلمة المرور
                            </label>
                            <input
                                {...register('password', {
                                    required: {
                                        value: true,
                                        message: 'Please enter a password'
                                    },
                                    pattern: {
                                        value: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
                                        message:
                                            'يجب أن تحتوي كلمة المرور على حرف خاص واحد وحرف كبير ورقم واحد'
                                    }
                                })}
                                placeholder="8 احرف - ارقام - رموز"
                                type="password"
                                name="password"
                                id="password"
                                dir="rtl"
                                className="w-full rounded-lg border-none bg-white px-2 py-2 text-right"
                            />
                            {errors.password && (
                                <span className="text-sm italic text-red-600">
                                    {errors.password?.message}
                                </span>
                            )}
                        </fieldset>
                        <fieldset className="flex w-full flex-col gap-2 text-right">
                            <label htmlFor="confirmPassword" className="text-lg">
                                تأكيد كلمة المرور
                            </label>
                            <input
                                {...register('confirmPassword', {
                                    required: {
                                        value: true,
                                        message: 'كلمة المرور مطلوبة'
                                    },
                                    validate: (value) => {
                                        if (watch('password') !== value) {
                                            return 'كلمة المرور غير متطابقة';
                                        }
                                    }
                                })}
                                placeholder="اعد كتابة كلمة المرور"
                                type="password"
                                name="confirmPassword"
                                id="confirmPassword"
                                dir="rtl"
                                className="w-full rounded-lg border-none bg-white px-2 py-2 text-right"
                            />
                            {errors.confirmPassword && (
                                <span className="text-sm italic text-red-600">
                                    {errors.confirmPassword?.message}
                                </span>
                            )}
                        </fieldset>
                        <div className="relative flex items-center">
                            <div className="flex-grow border-t border-white"></div>
                            <span className="mx-4 flex-shrink text-white">او الاستمرار مع</span>
                            <div className="flex-grow border-t border-white"></div>
                        </div>
                        <div className="flex flex-col items-center justify-center gap-2">
                            <button
                                className="flex w-full items-center justify-center rounded-lg border border-gray-300 bg-white px-4 py-2 shadow-sm hover:bg-gray-100"
                                onClick={(e) => handleGoogleLogin(e)}>
                                <FcGoogle className="mr-2 h-6 w-6" /> {/* Google icon */}
                                <span className="text-gray-700">Sign in with Google</span>
                            </button>
                        </div>

                        <button type="submit" ref={btnRef} hidden></button>
                        <Button text={'تسجيل'} onClick={signUp} className="mt-5" />
                    </form>
                </div>
            </div>
        </>
    );
}
