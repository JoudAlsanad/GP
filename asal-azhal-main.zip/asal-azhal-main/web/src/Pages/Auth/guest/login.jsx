import { useNavigate } from 'react-router-dom';
import Button from '../../../components/buttons/buttons';
import { useDispatch } from 'react-redux';
import toast from 'react-hot-toast';
import { useForm } from 'react-hook-form';
import { useRef } from 'react';
import { loginGuest } from '../../../store/authSlice';
import { ChevronLeftIcon } from '@heroicons/react/24/solid';

export default function GuestLogin() {
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const btnRef = useRef();

    const login = (e) => {
        e.preventDefault();
        btnRef.current.click();
    };

    const {
        register,
        handleSubmit,
        formState: { errors }
    } = useForm();

    const submitForm = (data) => {
        const { name } = data;

        dispatch(loginGuest(name))
            .then((data) => {
                toast.success('تم تسجيل الدخول بنجاح');
                console.log(data.data.user_type);
                switch (data.data.user_type) {
                    case 'employee':
                        navigate('/employee');
                        break;
                    case 'admin':
                        navigate('/admin');
                        break;
                    case 'student':
                        navigate('/student');
                        break;
                    case 'guest':
                        navigate('/guest');
                        break;
                    default:
                        break;
                }
            })
            .catch((error) => {
                toast.error(error.message);
            });
    };

    return (
        <>
            <div className="flex h-full w-full items-center justify-center">
                <div className="rounded-4xl bg-transBg flex w-1/2 flex-col gap-10 p-12">
                    <div className="flex items-center justify-between">
                        <ChevronLeftIcon
                            className="h-8 w-8 cursor-pointer"
                            onClick={() => navigate('/')}
                        />
                        <p className="text-3xl font-bold">اكمل كضيف</p>
                    </div>
                    <form onSubmit={handleSubmit(submitForm)} className="flex flex-col gap-5">
                        <fieldset className="flex w-full flex-col gap-2 text-right">
                            <label htmlFor="name" className="text-lg">
                                اسم
                            </label>
                            <input
                                {...register('name', {
                                    required: { value: true, message: 'البريد الإلكتروني مطلوب' }
                                })}
                                placeholder="اسم"
                                type="text"
                                name="name"
                                id="name"
                                dir="rtl"
                                className="w-full rounded-lg border-none bg-white px-2 py-2 text-right"
                            />
                            {errors.name && (
                                <span className="text-sm italic text-red-600">
                                    {errors.name?.message}
                                </span>
                            )}
                        </fieldset>

                        <button type="submit" ref={btnRef} hidden></button>
                        <Button text={'دخول'} onClick={login} className="mt-5" />
                    </form>
                </div>
            </div>
        </>
    );
}
