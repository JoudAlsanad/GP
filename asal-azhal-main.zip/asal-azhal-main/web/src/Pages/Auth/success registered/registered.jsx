import { Link } from "react-router-dom";
import Tick from "../../../components/tick/tick";
import ChevronLeft from "../../../components/icons/ChevronLeft";

export default function Registered() {
  return (
    <>
      <div className="he-full flex w-full flex-col items-center justify-center gap-5 text-white">
        <div className="rounded-full bg-transBg p-20">
          <Tick />
        </div>
        <p className="mt-8 text-xl font-bold text-white">تم تسجيلك بنجاح</p>
        <p className="text-white">
          سوف تتلقى رسالة بشأن التحقق من عنوان البريد الالكتروني
        </p>
        <Link to={"/"} className="mt-10 flex items-center gap-2">
          <ChevronLeft /> <span className="pb-2">العودة الى تسجيل الدخول</span>
        </Link>
      </div>
    </>
  );
}
