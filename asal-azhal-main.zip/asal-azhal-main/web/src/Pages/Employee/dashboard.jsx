import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getUserProfile } from '../../store/authSlice';
import UserIcon from '../../components/icons/UserIcon';
import DashboardLayout from '../../components/dashboard/layout';
import { FaqIcon } from '../../components/icons/FaqIcon';

export default function EmployeeDashboard() {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(getUserProfile());
    }, [dispatch]);

    const userProfile = useSelector((state) => state.auth.userProfile);
    const list = [
        {
            name: 'الملف الشخصي',
            icon: <UserIcon />,
            link: '/profile'
        },
        {
            name: 'أسئلة',
            icon: <FaqIcon />,
            link: '/employee/questions'
        }
    ];
    return (
        <>
            <div className="flex h-full w-full items-center justify-center">
                {userProfile && (
                    <DashboardLayout title={`اهلًا ${userProfile.name} !`} listOfIcons={list} />
                )}
            </div>
        </>
    );
}
