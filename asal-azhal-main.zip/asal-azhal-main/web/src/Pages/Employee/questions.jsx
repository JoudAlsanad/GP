import { useDispatch, useSelector } from 'react-redux';
import ChevronLeft from '../../components/icons/ChevronLeft';
import { FaqIcon } from '../../components/icons/FaqIcon';
import TransparentLogo from '../../components/icons/transparent logo';
import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { getUserProfile } from '../../store/authSlice';
import { fetchQuestions, updateQuestion } from '../../store/questionsSlice';
import { EditIcon2 } from '../../components/icons/editIcon';
import Modal from '../../components/Modal/modal';
import { useForm } from 'react-hook-form';
import Button from '../../components/buttons/buttons';
import toast from 'react-hot-toast';

export default function EmployeeQuestions() {
    const { userProfile } = useSelector((state) => state.auth);
    const { questions } = useSelector((state) => state.question);
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const [editQuestion, setEditQuestion] = useState(null);
    const [showEditModal, setShowEditModal] = useState(false);

    useEffect(() => console.log(questions), [dispatch, questions]);

    useEffect(() => {
        dispatch(getUserProfile());
        dispatch(fetchQuestions());
    }, [dispatch]);

    const toArabicNumerals = (num) => {
        const arabicNumerals = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
        return num
            .toString()
            .split('')
            .map((digit) => arabicNumerals[digit])
            .join('');
    };

    const {
        handleSubmit,
        reset,
        register,
        formState: { errors }
    } = useForm();
    const submitForm = (data) => {
        dispatch(updateQuestion(editQuestion.id, data))
            .then(() => {
                toast.success('Question edited successfully');
                dismissModal();
                reset();
            })
            .catch((error) => toast.error(error.message));
    };

    const dismissModal = () => {
        setEditQuestion(null);
        setShowEditModal(false);
    };

    return (
        <main className="h-lvh w-full bg-white">
            {showEditModal && editQuestion && (
                <Modal modalClassName={'w-1/3 text-right flex flex-col gap-5'}>
                    <p className="text-center text-xl font-bold">تحرير سؤال</p>
                    <p className="w-full text-right text-lg font-bold">السؤال</p>
                    <p className="w-full text-right">{editQuestion.question}</p>
                    <form
                        onSubmit={handleSubmit(submitForm)}
                        className="flex w-full flex-col gap-5">
                        <fieldset className="flex w-full flex-col gap-2 text-right">
                            <label htmlFor="employee_answer" className="text-lg font-bold">
                                الجواب
                            </label>
                            <textarea
                                className="w-full rounded-lg bg-white px-2 py-2 text-right"
                                name="employee_answer"
                                rows={4}
                                id="employee_answer"
                                dir="rtl"
                                {...register('employee_answer', {
                                    required: 'Employee Answer can not be blank'
                                })}
                            />
                            {errors.employee_answer && (
                                <span className="text-sm italic text-red-600">
                                    {errors.employee_answer?.message}
                                </span>
                            )}
                        </fieldset>

                        <div className="flex flex-row-reverse gap-4">
                            <Button className="px-4" text={'تحرير'}></Button>
                            <Button
                                className="px-4"
                                text={'اغلاق '}
                                onClick={dismissModal}></Button>
                        </div>
                    </form>
                </Modal>
            )}
            <div className="flex w-full items-center justify-between px-10">
                <TransparentLogo />
                <span className="text-xl font-bold">اهلًا {userProfile?.name || 'admin'} !</span>
            </div>
            <hr />
            <div className="mt-5 flex w-full items-center justify-between px-10">
                <ChevronLeft
                    color="black"
                    onClick={() => {
                        navigate(-1);
                    }}
                />
                <div className="flex items-center gap-3">
                    أسئلة <FaqIcon />
                </div>
            </div>
            <table className="my-10 w-full table-auto">
                <thead>
                    <tr className="">
                        <th className="w-1/12 border border-y-black py-4">تحرير</th>
                        <th className="w-3/12 border border-y-black py-4">إجابة الموظف</th>
                        <th className="w-3/12 border border-y-black py-4">الجواب</th>
                        <th className="w-2/12 border border-y-black py-4">السؤال</th>
                        <th className="w-2/12 border border-y-black py-4">التاريخ والوقت</th>
                        <th className="w-1/12 border border-y-black py-4">رقم</th>
                    </tr>
                </thead>
                <tbody>
                    {questions.length > 0 &&
                        questions.map((question, idx) => {
                            return (
                                <tr key={idx} className="text-right">
                                    <td
                                        className="border px-2 py-2"
                                        onClick={() => {
                                            setEditQuestion(question);
                                            setShowEditModal(true);
                                            reset({
                                                employee_answer: question.employee_answer
                                            });
                                        }}>
                                        <div className="flex cursor-pointer justify-center">
                                            <EditIcon2 />
                                        </div>
                                    </td>
                                    <td className="border px-2 py-2">{question.employee_answer}</td>
                                    <td className="border px-2 py-2">{question.ai_answer}</td>
                                    <td className="border px-2 py-2">{question.question}</td>
                                    <td className="border px-2 py-2 text-center">
                                        {new Date(question.updated_at).toLocaleDateString('ar-SA')}
                                    </td>
                                    <td className="border px-2 py-2 text-center">
                                        {toArabicNumerals(idx + 1)}
                                    </td>
                                </tr>
                            );
                        })}
                </tbody>
            </table>
            {questions.length === 0 && (
                <div className="w-full text-center text-xl font-bold">
                    لم يتم العثور على أي أسئلة
                </div>
            )}
        </main>
    );
}
