import { Outlet } from 'react-router-dom';
import HeroLogo from '../components/Hero Logo/hero logo';

export default function Home() {
    return (
        <>
            <main className="flex min-h-lvh items-center justify-between">
                <HeroLogo />
                <div className="flex h-full w-full items-center justify-center">
                    <Outlet />
                    <div className="w-full"></div>
                </div>
            </main>
        </>
    );
}
