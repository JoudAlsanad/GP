import { useDispatch, useSelector } from 'react-redux';
import ChevronLeft from '../../components/icons/ChevronLeft';
import { FaqIcon } from '../../components/icons/FaqIcon';
import TransparentLogo from '../../components/icons/transparent logo';
import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { getUserProfile } from '../../store/authSlice';
import { delQuestion, fetchQuestions } from '../../store/questionsSlice';
import Modal from '../../components/Modal/modal';
import Button from '../../components/buttons/buttons';
import TrashIcon from '../../components/icons/trashIcon';
import toast from 'react-hot-toast';

export default function StudentQuestions() {
    const { userProfile } = useSelector((state) => state.auth);
    const { questions } = useSelector((state) => state.question);
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const [deleteQuestion, setDeleteQuestion] = useState(null);
    const [showDeleteModal, setShowDeleteModal] = useState(false);

    useEffect(() => console.log(questions), [dispatch, questions]);

    useEffect(() => {
        dispatch(getUserProfile());
        dispatch(fetchQuestions());
    }, [dispatch]);

    const toArabicNumerals = (num) => {
        const arabicNumerals = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
        return num
            .toString()
            .split('')
            .map((digit) => arabicNumerals[digit])
            .join('');
    };

    const dismissModal = () => {
        setDeleteQuestion(null);
        setShowDeleteModal(false);
    };

    const confirmDelete = (id) => {
        dispatch(delQuestion(id))
            .then(() => {
                toast.success('Successfull deleted question');
                dismissModal();
            })
            .catch((error) => {
                toast.error(error?.message || 'Failed to delete question');
            });
    };

    return (
        <main className="h-lvh w-full bg-white">
            {showDeleteModal && deleteQuestion && (
                <Modal modalClassName={'w-1/3 text-right flex flex-col gap-5'}>
                    <p className="my-5 text-lg">هل أنت متأكد أنك تريد حذف هذا السؤال؟</p>
                    <div className="flex flex-row-reverse gap-4">
                        <Button
                            className="px-4"
                            text={'مسح'}
                            onClick={() => confirmDelete(deleteQuestion.id)}></Button>
                        <Button className="px-4" text={'اغلاق'} onClick={dismissModal}></Button>
                    </div>
                </Modal>
            )}
            <div className="flex w-full items-center justify-between px-10">
                <TransparentLogo />
                <span className="text-xl font-bold">اهلًا {userProfile?.name || 'admin'} !</span>
            </div>
            <hr />
            <div className="mt-5 flex w-full items-center justify-between px-10">
                <ChevronLeft
                    color="black"
                    onClick={() => {
                        navigate(-1);
                    }}
                />
                <FaqIcon />
            </div>
            <table className="my-10 w-full table-auto">
                <thead>
                    <tr className="">
                        <th className="w-1/12 border border-y-black py-4">حذف</th>
                        <th className="w-3/12 border border-y-black py-4">اجابة الموظف المختص</th>
                        <th className="w-3/12 border border-y-black py-4">الجواب</th>
                        <th className="w-2/12 border border-y-black py-4">السؤال</th>
                        <th className="w-2/12 border border-y-black py-4">التاريخ والوقت</th>
                        <th className="w-1/12 border border-y-black py-4">رقم</th>
                    </tr>
                </thead>
                <tbody>
                    {questions.length > 0 &&
                        questions.map((question, idx) => {
                            return (
                                <tr key={idx} className="text-right">
                                    <td
                                        className="border px-2 py-2"
                                        onClick={() => {
                                            setDeleteQuestion(question);
                                            setShowDeleteModal(true);
                                        }}>
                                        <div className="flex cursor-pointer justify-center">
                                            <TrashIcon />
                                        </div>
                                    </td>
                                    <td className="border px-2 py-2">{question.employee_answer}</td>
                                    <td className="border px-2 py-2">{question.ai_answer}</td>
                                    <td className="border px-2 py-2">{question.question}</td>
                                    <td className="border px-2 py-2 text-center">
                                        {new Date(question.updated_at).toLocaleDateString('ar-SA')}
                                    </td>
                                    <td className="border px-2 py-2 text-center">
                                        {toArabicNumerals(idx + 1)}
                                    </td>
                                </tr>
                            );
                        })}
                </tbody>
            </table>
            {questions.length === 0 && (
                <div className="w-full text-center text-xl font-bold">
                    لم يتم العثور على أي أسئلة
                </div>
            )}
        </main>
    );
}
