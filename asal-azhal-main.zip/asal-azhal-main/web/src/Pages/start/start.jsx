import { Link } from 'react-router-dom';

export default function Start() {
    return (
        <>
            <div className="flex h-full w-full items-start text-white">
                <div className="flex h-full flex-col items-center justify-center gap-20">
                    <p className="w-3/4 text-center text-xl xl:w-1/2 xl:text-2xl">
                        سواء كنت طالبًا جديدًا تبحث عن معلومات، أو طالبًا حاليًا يحتاج إلى توضيح في
                        قواعد معينة، فأنا هنا لمساعدتك.
                    </p>
                    <div className="rounded-4xl flex w-3/4 flex-col bg-[rgba(255,255,255,0.5)] px-2 py-5 text-center text-2xl xl:px-10 xl:text-3xl">
                        <div className="flex flex-row items-center divide-x-2 py-3 text-center">
                            <Link to={'/guest-login'} className="w-full py-2">
                                اكمل كضيف
                            </Link>
                            <Link to={'/login'} className="w-full py-2">
                                تسجيل الدخول
                            </Link>
                        </div>
                        <Link to={'/signup'} className="py-5">
                            تسجيل جديد
                        </Link>
                    </div>
                </div>
            </div>
        </>
    );
}
