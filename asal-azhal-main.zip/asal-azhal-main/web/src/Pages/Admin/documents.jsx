/* eslint-disable react/prop-types */
import { useNavigate } from 'react-router-dom';
import ChevronLeft from '../../components/icons/ChevronLeft';
import { DocumentsIcon2 } from '../../components/icons/DocumentsIcon';
import EditIcon from '../../components/icons/editIcon';
import TransparentLogo from '../../components/icons/transparent logo';
import TrashIcon from '../../components/icons/trashIcon';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect, useRef, useState } from 'react';
import { addDoc, deleteDoc, editDoc, getDocs } from '../../store/documentSlice';
import toast from 'react-hot-toast';
import { downloadPdf } from '../../api/documentApis';
import Modal from '../../components/Modal/modal';
import Button from '../../components/buttons/buttons';
import { useForm } from 'react-hook-form';
import PlusIcon from '../../components/icons/PlusIcon';

export default function AdminDocuments() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const { userProfile } = useSelector((state) => state.auth);
    const [documents, setDocuments] = useState([]);
    const [reload, setReload] = useState(false);
    const [showAddModal, setShowAddModal] = useState(false);

    const fetchDocs = () => {
        dispatch(getDocs())
            .then((data) => {
                setDocuments(data.data);
            })
            .catch((error) => {
                toast.error(error.message);
            });
    };

    useEffect(fetchDocs, [dispatch, reload]);
    useEffect(fetchDocs, [dispatch]);

    return (
        <>
            <AddDocumentModal
                show={showAddModal}
                setShow={setShowAddModal}
                reloadDocuments={setReload}
            />
            <main className="h-lvh w-full bg-white px-10">
                <div className="flex w-full items-center justify-between">
                    <TransparentLogo />
                    <span className="text-xl font-bold">
                        اهلًا {userProfile?.name || 'admin'} !
                    </span>
                </div>
                <hr />
                <div className="mt-5 flex w-full items-center justify-between">
                    <ChevronLeft
                        color="black"
                        onClick={() => {
                            navigate(-1);
                        }}
                    />
                    <DocumentsIcon2 />
                </div>
                <div className="my-10 grid grid-cols-5 gap-y-10" style={{ direction: 'rtl' }}>
                    {documents.length > 0 &&
                        documents.map((doc, index) => {
                            return (
                                <DocumentPreview
                                    key={index}
                                    document={doc}
                                    reloadDocuments={setReload}
                                />
                            );
                        })}
                    {documents.length === 0 && (
                        <div className="text-xl font-bold">لم يتم العثور على وثائق.</div>
                    )}
                </div>
                <div
                    className="fixed bottom-10 left-10 flex cursor-pointer items-center gap-4 rounded-xl bg-white p-4 text-lg"
                    onClick={() => setShowAddModal(true)}>
                    اضافة مستندات
                    <PlusIcon />
                </div>
            </main>
        </>
    );
}

function DocumentPreview({ document, reloadDocuments }) {
    const dispatch = useDispatch();
    const buttonRef = useRef();

    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);

    const {
        register,
        handleSubmit,
        formState: { errors }
    } = useForm({
        defaultValues: {
            title: document.title
        }
    });

    const dismissEditModel = () => {
        setShowEditModal(false);
    };

    const submitEditForm = (data) => {
        const formData = new FormData();

        formData.append('title', data.title);
        formData.append('pdf', data.file[0]);

        dispatch(editDoc(formData, document.id))
            .then(() => {
                toast.success('Document edited successfully.');
                reloadDocuments((prevState) => ({
                    reload: !prevState
                }));
                dismissEditModel();
            })
            .catch((e) => console.log(e));
    };

    const editDocument = (e) => {
        e.preventDefault();
        buttonRef.current.click();
    };

    const dismissDeleteModal = () => {
        setShowDeleteModal(false);
    };
    const confirmDelete = (id) => {
        dispatch(deleteDoc(id))
            .then(() => {
                toast.success('Document deleted successfully.');
                reloadDocuments((prevState) => ({
                    reload: !prevState
                }));
            })
            .catch((e) => toast.error(e.message))
            .finally(dismissDeleteModal);
    };
    return (
        <>
            {showEditModal && (
                <Modal>
                    <div className="mt-10 flex flex-col gap-5">
                        <form
                            onSubmit={handleSubmit(submitEditForm)}
                            className="flex flex-col gap-5">
                            <fieldset className="flex w-full flex-col gap-2 text-right">
                                <label htmlFor="title" className="text-lg">
                                    عنوان الملف{' '}
                                </label>
                                <input
                                    {...register('title', {
                                        required: {
                                            value: true,
                                            message: 'عنوان الوثيقة مطلوب'
                                        }
                                    })}
                                    placeholder="عنوان الوثيقة"
                                    type="title"
                                    name="title"
                                    id="title"
                                    dir="rtl"
                                    className="w-full rounded-lg border border-black bg-white px-2 py-2"
                                />
                                {errors.title && (
                                    <span className="text-sm italic text-red-600">
                                        {errors.title?.message}
                                    </span>
                                )}
                            </fieldset>
                            <fieldset className="flex w-full flex-col gap-2 text-right">
                                <label htmlFor="file" className="text-lg">
                                    تحميل الملف:
                                </label>
                                <input
                                    type="file"
                                    id="file"
                                    {...register('file', { required: 'الملف مطلوب' })}
                                />
                                {errors.file && (
                                    <span className="text-sm italic text-red-600">
                                        {errors.file?.message}
                                    </span>
                                )}
                            </fieldset>
                            <button hidden ref={buttonRef} type="submit"></button>
                        </form>
                        <div className="flex w-full flex-row gap-5">
                            <Button
                                text={'متأكد'}
                                className="min-w-20 px-4"
                                onClick={editDocument}
                            />
                            <Button
                                text={'الغاء'}
                                className="min-w-20 px-4"
                                onClick={dismissEditModel}
                            />
                        </div>
                    </div>
                </Modal>
            )}
            {showDeleteModal && (
                <Modal>
                    هل انت متأكد من حذف الملف؟{' '}
                    <div className="mt-10 flex gap-5">
                        <Button
                            text={'متأكد'}
                            className="w-20"
                            onClick={() => confirmDelete(document.id)}
                        />
                        <Button text={'الغاء'} className="w-20" onClick={dismissDeleteModal} />
                    </div>
                </Modal>
            )}
            <div className="mx-2 flex w-fit cursor-pointer flex-col gap-5">
                <div className="from-gradStart via-gradMid to-gradEnd rounded-3xl bg-gradient-to-r">
                    <div
                        className="m-2 h-80 w-60 rounded-[calc(1.5rem-0.5rem)] bg-white p-1"
                        // outerRadius = innerRadius + margin
                        onClick={() => downloadPdf(document.pdf, document.title)}>
                        {document.thumbnail ? (
                            <img
                                src={document.thumbnail}
                                alt="Doc Thumbnail"
                                className="object-fit h-full w-full rounded-xl bg-cover"
                            />
                        ) : (
                            <img
                                src={'/images/pdf thumbnail.png'}
                                alt="Default Doc Thumbnail"
                                className="h-full w-full object-contain"
                            />
                        )}
                    </div>
                </div>
                <div className="flex items-center justify-center gap-3">
                    <div
                        onClick={() => {
                            setShowDeleteModal(true);
                        }}>
                        <TrashIcon />
                    </div>
                    <div
                        onClick={() => {
                            setShowEditModal(true);
                        }}>
                        <EditIcon />
                    </div>
                </div>
            </div>
        </>
    );
}

function AddDocumentModal({ show, setShow, reloadDocuments }) {
    const dispatch = useDispatch();

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset
    } = useForm({
        defaultValues: {
            title: ''
        }
    });

    const btnRef = useRef();

    const submitForm = (data) => {
        const formData = new FormData();

        formData.append('title', data.title);
        formData.append('pdf', data.file[0]);

        dispatch(addDoc(formData))
            .then(() => {
                toast.success('Document added successfully.');
                reloadDocuments((prevState) => ({
                    reload: !prevState
                }));
                dismissAddDocumentModal();
            })
            .catch((e) => console.log(e));
        reset();
    };

    const addDocument = (e) => {
        e.preventDefault();
        btnRef.current.click();
    };

    const dismissAddDocumentModal = () => {
        setShow(false);
    };

    return (
        <>
            {show && (
                <Modal>
                    <div className="mt-10 flex flex-col items-end gap-5 text-right">
                        <form onSubmit={handleSubmit(submitForm)} className="flex flex-col gap-5">
                            <fieldset className="flex w-full flex-col gap-2 text-right">
                                <label htmlFor="title" className="text-lg">
                                    عنوان الملف
                                </label>
                                <input
                                    {...register('title', {
                                        required: {
                                            value: true,
                                            message: 'Document title is required.'
                                        }
                                    })}
                                    placeholder="Document Title"
                                    type="title"
                                    name="title"
                                    id="title"
                                    dir="rtl"
                                    className="w-full rounded-lg border border-black bg-white px-2 py-2"
                                />
                                {errors.title && (
                                    <span className="text-sm italic text-red-600">
                                        {errors.title?.message}
                                    </span>
                                )}
                            </fieldset>
                            <fieldset className="flex w-full flex-col items-end gap-2 text-right">
                                <label htmlFor="file" className="text-lg">
                                    :تحميل الملف
                                </label>
                                <input
                                    className="flex flex-row-reverse"
                                    type="file"
                                    id="file"
                                    {...register('file', { required: 'File is required' })}
                                />
                                {errors.file && (
                                    <span className="text-sm italic text-red-600">
                                        {errors.file?.message}
                                    </span>
                                )}
                            </fieldset>
                            <button type="submit" ref={btnRef} hidden></button>
                        </form>
                        <div className="flex w-full flex-row justify-end gap-5">
                            <Button
                                text={'الغاء'}
                                className="min-w-20 px-4"
                                onClick={dismissAddDocumentModal}
                            />
                            <Button
                                text={'إضافة مستند'}
                                onClick={addDocument}
                                className="min-w-20 px-4"
                            />
                        </div>
                    </div>
                </Modal>
            )}
        </>
    );
}
