/* eslint-disable react/prop-types */
import { useNavigate } from 'react-router-dom';
import ChevronLeft from '../../components/icons/ChevronLeft';
import TransparentLogo from '../../components/icons/transparent logo';
import FaqIconText from '../../components/icons/FaqIcon';

import { useDispatch, useSelector } from 'react-redux';
import { useEffect, useRef, useState } from 'react';
import { addNewFaq, editFaq, fetchFaqs, deleteFaq } from '../../store/faqSlice';
import { EditIcon2 } from '../../components/icons/editIcon';
import DeleteIcon from '../../components/icons/DeleteIcon';
import toast from 'react-hot-toast';
import Modal from '../../components/Modal/modal';
import { useForm } from 'react-hook-form';
import Button from '../../components/buttons/buttons';
import PlusIcon from '../../components/icons/PlusIcon';

export default function AdminFaq() {
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const [faqs, setFaqs] = useState([]);
    const [showEditModal, setShowEditModal] = useState(false);
    const [editFaq, setEditFaq] = useState(null);
    const [showAddNewModal, setShowNewModal] = useState(false);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [reload, setReload] = useState(false);

    const triggerReload = () => {
        setReload((prevState) => !prevState);
    };

    const dismissAddNewModal = () => {
        setShowNewModal(false);
    };

    const dismissEditModal = () => {
        setShowEditModal(false);
    };

    const getLatestFaqs = () => {
        dispatch(fetchFaqs())
            .then((data) => setFaqs(data.data))
            .catch((error) => toast.error(error));
    };

    useEffect(getLatestFaqs, [dispatch, reload]);

    useEffect(getLatestFaqs, [dispatch]);

    const toArabicNumerals = (num) => {
        const arabicNumerals = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
        return num
            .toString()
            .split('')
            .map((digit) => arabicNumerals[digit])
            .join('');
    };

    const handleFaqDelete = (faqId) => {
        dispatch(deleteFaq(faqId))
            .then(() => {
                getLatestFaqs();
                toast.success('Deleted FAQ');
                setShowDeleteModal(false);
            })
            .catch((error) => {
                toast.error(error.message);
            });
    };
    const { userProfile } = useSelector((state) => state.auth);

    return (
        <>
            {showAddNewModal && (
                <AddNewModal reloadFunc={triggerReload} dismissModal={dismissAddNewModal} />
            )}
            {showEditModal && editFaq && (
                <EditModal
                    faq={editFaq}
                    dismissModal={dismissEditModal}
                    reloadFunc={triggerReload}
                />
            )}
            {showDeleteModal && (
                <DeleteModal
                    faq={editFaq}
                    dismissModal={() => setShowDeleteModal(false)}
                    handleFaqDelete={handleFaqDelete}
                />
            )}
            <main className="h-lvh w-full bg-white">
                <div className="flex w-full items-center justify-between px-10">
                    <TransparentLogo />
                    <span className="text-xl font-bold">
                        اهلًا {userProfile?.name || 'admin'} !
                    </span>
                </div>
                <hr />
                <div className="mt-5 flex w-full items-center justify-between px-10">
                    <ChevronLeft
                        color="black"
                        onClick={() => {
                            navigate(-1);
                        }}
                    />
                    <FaqIconText />
                </div>
                <table className="my-10 w-full table-auto">
                    <thead>
                        <tr className="">
                            <th className="w-1/12 border border-y-black py-4">تعديل</th>
                            <th className="w-6/12 border border-y-black py-4">الجواب</th>
                            <th className="w-4/12 border border-y-black py-4">السؤال</th>
                            <th className="w-1/12 border border-y-black py-4">رقم</th>
                        </tr>
                    </thead>
                    <tbody className="text-right">
                        {faqs.length > 0 &&
                            faqs.map((faq, idx) => {
                                return (
                                    <tr key={idx}>
                                        <td className="border p-2">
                                            <div className="flex items-center justify-between px-4">
                                                <div
                                                    onClick={() => {
                                                        setEditFaq(faq);
                                                        setShowEditModal(true);
                                                    }}
                                                    className="cursor-pointer">
                                                    <EditIcon2 className="h-6 w-6 cursor-pointer" />
                                                </div>
                                                <div
                                                    onClick={() => {
                                                        setEditFaq(faq);
                                                        setShowDeleteModal(true);
                                                    }}>
                                                    <DeleteIcon className="h-6 w-6 cursor-pointer" />
                                                </div>
                                            </div>
                                        </td>
                                        <td className="border p-2">{faq.answer}</td>
                                        <td className="border p-2">{faq.question}</td>
                                        <td className="border p-2 text-center">
                                            {toArabicNumerals(idx + 1)}
                                        </td>
                                    </tr>
                                );
                            })}
                    </tbody>
                </table>
                {faqs.length === 0 && (
                    <div className="w-full text-center text-xl font-bold">
                        لم يتم العثور على أسئلة متكررة
                    </div>
                )}
            </main>
            <div
                className="fixed bottom-10 left-10 flex cursor-pointer items-center gap-4 rounded-xl border border-black bg-white p-4 text-lg"
                onClick={() => setShowNewModal(true)}>
                اضافة سؤال
                <PlusIcon />
            </div>
        </>
    );
}

function AddNewModal({ dismissModal, reloadFunc }) {
    const {
        register,
        handleSubmit,
        formState: { errors }
    } = useForm();

    const dispatch = useDispatch();

    // const buttonRef = useRef();

    const submitForm = (data) => {
        dispatch(addNewFaq(data))
            .then(() => {
                reloadFunc();
                dismissModal();
                toast.success('Added new FAQ');
            })
            .catch((error) => {
                dismissModal();
                toast.error(error.message);
            });
    };

    return (
        <Modal modalClassName={'w-1/3'}>
            <form onSubmit={handleSubmit(submitForm)} className="flex w-full flex-col gap-5">
                <fieldset className="flex w-full flex-col gap-2 text-right">
                    <label htmlFor="question" className="text-lg">
                        السؤال
                    </label>
                    <textarea
                        className="w-full rounded-lg bg-white px-2 py-2 text-right"
                        rows={2}
                        name="question"
                        id="question"
                        dir="rtl"
                        {...register('question', { required: 'Question can not be blank' })}
                    />
                    {errors.question && (
                        <span className="text-sm italic text-red-600">
                            {errors.question?.message}
                        </span>
                    )}
                </fieldset>
                <fieldset className="flex w-full flex-col gap-2 text-right">
                    <label htmlFor="answer" className="text-lg">
                        الجواب
                    </label>
                    <textarea
                        className="w-full rounded-lg bg-white px-2 py-2 text-right"
                        name="answer"
                        rows={4}
                        id="answer"
                        dir="rtl"
                        {...register('answer', {
                            required: 'Answer can not be blank'
                        })}
                    />
                    {errors.answer && (
                        <span className="text-sm italic text-red-600">
                            {errors.answer?.message}
                        </span>
                    )}
                </fieldset>
                {/* <button type="submit" ref={buttonRef} hidden></button> */}
                <div className="flex flex-row-reverse gap-4">
                    <Button
                        className="px-4"
                        text={'اضافة'}
                        onClick={handleSubmit(submitForm)}></Button>
                    <Button className="px-4" text={'الغاء'} onClick={dismissModal}></Button>
                </div>
            </form>
        </Modal>
    );
}

function EditModal({ faq, dismissModal, reloadFunc }) {
    const {
        register,
        handleSubmit,
        formState: { errors }
    } = useForm({
        defaultValues: {
            question: faq.question,
            answer: faq.answer
        }
    });

    const dispatch = useDispatch();

    const buttonRef = useRef();

    const submitForm = (data) => {
        dispatch(editFaq(faq.id, data))
            .then(() => {
                reloadFunc();
                dismissModal();
                toast.success('Edited FAQ');
            })
            .catch((error) => {
                dismissModal();
                toast.error(error.message);
            });
    };

    return (
        <>
            <Modal modalClassName={'w-1/3'}>
                <form onSubmit={handleSubmit(submitForm)} className="flex w-full flex-col gap-5">
                    <fieldset className="flex w-full flex-col gap-2 text-right">
                        <label htmlFor="question" className="text-lg">
                            السؤال
                        </label>
                        <textarea
                            className="w-full rounded-lg bg-white px-2 py-2 text-right"
                            rows={2}
                            name="question"
                            id="question"
                            dir="rtl"
                            {...register('question', { required: 'Question can not be blank' })}
                        />
                        {errors.question && (
                            <span className="text-sm italic text-red-600">
                                {errors.question?.message}
                            </span>
                        )}
                    </fieldset>
                    <fieldset className="flex w-full flex-col gap-2 text-right">
                        <label htmlFor="answer" className="text-lg">
                            الجواب
                        </label>
                        <textarea
                            className="w-full rounded-lg bg-white px-2 py-2 text-right"
                            name="answer"
                            rows={4}
                            id="answer"
                            dir="rtl"
                            {...register('answer', {
                                required: 'Answer can not be blank'
                            })}
                        />
                        {errors.answer && (
                            <span className="text-sm italic text-red-600">
                                {errors.answer?.message}
                            </span>
                        )}
                    </fieldset>
                    <button type="submit" ref={buttonRef} hidden></button>
                    <div className="flex flex-row-reverse gap-4">
                        <Button
                            className="px-4"
                            text={'تعديل'}
                            onClick={() => buttonRef.current.click()}></Button>
                        <Button className="px-4" text={'الغاء'} onClick={dismissModal}></Button>
                    </div>
                </form>
            </Modal>
        </>
    );
}

const DeleteModal = ({ faq, dismissModal, handleFaqDelete }) => {
    return (
        <Modal modalClassName={'w-1/3 text-right flex flex-col gap-5'}>
            <p className="my-5 text-lg">هل انت متأكد من حذف السؤال؟</p>
            <div className="flex flex-row-reverse gap-4">
                <Button
                    className="px-4"
                    text={'حذف '}
                    onClick={() => handleFaqDelete(faq.id)}></Button>
                <Button className="px-4" text={'الغاء'} onClick={dismissModal}></Button>
            </div>
        </Modal>
    );
};
