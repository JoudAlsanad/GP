/* eslint-disable react/prop-types */
import { useNavigate } from 'react-router-dom';
import ChevronLeft from '../../components/icons/ChevronLeft';
import Button from '../../components/buttons/buttons';
import TransparentLogo from '../../components/icons/transparent logo';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect, useRef, useState } from 'react';
import { askQuestion, clearConversation, getLastConvo, setMessages } from '../../store/chatSlice';
import { Accordion } from '@szhsin/react-accordion';
import { AccordionItem } from '../../components/Accordion/AccordionItem';
import { fetchFaqs } from '../../store/faqSlice';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import Modal from '../../components/Modal/modal';
import CloseButton from '../../components/icons/CloseButton';
import { addNewReview } from '../../store/reviewSlice';
import { downloadPdf } from '../../api/documentApis';
import Markdown from 'react-markdown';
import { ThreeDots } from 'react-loader-spinner';
import { PaperAirplaneIcon } from '@heroicons/react/24/solid';
import { addNewQuestion } from '../../store/questionsSlice';

export default function AdminChat() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [showFaqs, setShowFaqs] = useState(false);
    const [rating, setRating] = useState(0);
    const [selectedQuestion, setSelectedQuestion] = useState(null);
    const [selectedAnswer, setSelectedAnswer] = useState(null);

    const [showEvaluateModal, setShowEvaluateModal] = useState(false);
    const [showReviewModal, setShowReviewModal] = useState(false);

    const { messages, conversation } = useSelector((state) => state.chat);
    const { faqs } = useSelector((state) => state.faq);
    const chatLoading = useSelector((state) => state.chat.loading);

    const messagesEndRef = useRef(null);

    const scrollToBottom = () => {
        if (messagesEndRef.current) {
            messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const dismissEvaluationModal = () => {
        setShowEvaluateModal(false);
    };

    const dismissReviewModal = () => {
        setShowReviewModal(false);
        dismissEvaluationModal();
        setSelectedAnswer(null);
        setRating(0);
        setSelectedQuestion(null);
    };

    const reviewAnswer = () => {
        dismissEvaluationModal(true);
        setShowReviewModal(true);
    };

    // useEffect(() => console.log(messages, conversation), [dispatch, messages, conversation]);

    useEffect(() => {
        dispatch(getLastConvo());
        dispatch(fetchFaqs());
    }, [dispatch]);
    const user = useSelector((state) => state.auth.userProfile);

    const sendMsg = (data) => {
        reset();
        dispatch(setMessages([...messages, { role: 'user', content: data.question }]));
        dispatch(askQuestion(conversation.uuid, data.question))
            .then(() => {
                reset();
            })
            .catch((error) => toast.error(error.message));
    };

    const { register, handleSubmit, reset } = useForm();

    return (
        <>
            {showReviewModal && (
                <QuestionReviewModal
                    selectedAnswer={selectedAnswer}
                    selectedQuestion={selectedQuestion}
                    dismissModal={dismissReviewModal}
                    rating={rating}
                />
            )}
            {showEvaluateModal && (
                <QuestionRatingModal
                    selectedAnswer={selectedAnswer}
                    selectedQuestion={selectedQuestion}
                    rating={rating}
                    setRating={setRating}
                    dismissModal={dismissEvaluationModal}
                    showEvaluationModal={reviewAnswer}
                />
            )}
            <div className="flex h-[80vh] w-full items-center justify-center">
                <div className="rounded-4xl relative flex h-full w-2/3 flex-col bg-white p-5">
                    <div className="mb-2 flex items-center justify-between">
                        <ChevronLeft color="black" onClick={() => navigate(-1)} />
                        <div className="flex items-center gap-2">
                            <p className="rounded-xl text-center text-xl font-bold">اسأل و ازهل</p>
                            <TransparentLogo />
                        </div>
                    </div>
                    <hr />
                    {conversation && (
                        <div className="flex w-full items-start py-2">
                            <p className="w-full text-center text-sm text-gray-700">
                                {new Date(conversation.updated_at).toLocaleString('en-US', {
                                    month: 'short',
                                    day: 'numeric',
                                    year: 'numeric',
                                    hour: 'numeric',
                                    minute: 'numeric',
                                    hour12: true
                                })}
                            </p>
                        </div>
                    )}
                    <div className="mb-14 mt-5 flex w-full flex-col gap-4 overflow-auto py-2">
                        <TransparentLogo />
                        <div className="w-fit pl-8">
                            <p
                                className="bg-aiChatColor rounded-r-4xl rounded-b-4xl w-fit px-3 py-2"
                                dir="rtl">
                                مرحبًا {user?.name}, كيف اقدر اساعدك؟
                            </p>
                        </div>
                        <div className="w-fit pl-8">
                            <div className="relative mb-4 flex items-center">
                                <div className="flex-grow border-t border-gray-700"></div>
                                <span className="mx-4 flex-shrink text-gray-700">
                                    او يرجى اختيار
                                </span>
                                <div className="flex-grow border-t border-gray-700"></div>
                            </div>
                            <p
                                className="bg-aiChatColor rounded-r-4xl rounded-b-4xl cursor-pointer px-24 py-2 font-bold"
                                onClick={() => setShowFaqs((state) => !state)}>
                                الاسئلة الاكثر تكرارًا
                            </p>
                        </div>
                        {showFaqs && (
                            <div className="">
                                <Accordion>
                                    {faqs &&
                                        faqs.map((faq, idx) => {
                                            return (
                                                <AccordionItem key={idx} header={faq.question}>
                                                    {faq.answer}
                                                </AccordionItem>
                                            );
                                        })}
                                </Accordion>
                            </div>
                        )}
                        {messages &&
                            messages.map((msg, idx) => {
                                return msg.role === 'user' ? (
                                    <UserMessage key={idx} content={msg.content} />
                                ) : (
                                    <AIMessage
                                        chatId={conversation.uuid}
                                        showRatingModal={setShowEvaluateModal}
                                        selectedQuestion={setSelectedQuestion}
                                        setSelectedAnswer={setSelectedAnswer}
                                        messages={messages}
                                        index={idx - 1}
                                        key={idx}
                                        aiMsg={msg}
                                    />
                                );
                            })}
                        {chatLoading && (
                            <div className="flex h-full w-full items-center justify-center">
                                <ThreeDots
                                    visible={chatLoading}
                                    color="#845AFA"
                                    height={50}
                                    width={50}
                                    ariaLabel="three-dots-loading"
                                />
                            </div>
                        )}
                        <div ref={messagesEndRef}></div>
                    </div>
                    <div className="absolute bottom-5 mx-auto flex w-[80%] justify-center pl-10">
                        <form onSubmit={handleSubmit(sendMsg)} className="w-full">
                            <div className="flex w-full flex-row-reverse items-center justify-between gap-4">
                                <input
                                    {...register('question')}
                                    type="text"
                                    className="w-full rounded-xl border text-right"
                                    placeholder="اكتب ..."
                                    dir="rtl"
                                />
                                <button type="submit" className="flex items-center justify-center">
                                    <PaperAirplaneIcon className="text-gradMid h-8 w-8 rotate-180" />
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </>
    );
}

function QuestionRatingModal({
    dismissModal,
    showEvaluationModal,
    rating,
    setRating,
    selectedAnswer,
    selectedQuestion
}) {
    const dispatch = useDispatch();
    return (
        <Modal modalClassName="w-1/3 flex flex-col gap-5 relative">
            <div onClick={() => dismissModal()} className="absolute left-8 top-8 cursor-pointer">
                <CloseButton />
            </div>
            <div className="flex w-full items-center justify-center">
                <p className="text-lg font-bold">تقييمك للإجابة؟</p>
            </div>
            <StarRating rating={rating} setRating={setRating} />
            <Button
                text={'ارسال'}
                onClick={() => {
                    // console.log(selectedAnswer, selectedQuestion);
                    if (rating <= 3) {
                        showEvaluationModal(true);
                    } else {
                        dispatch(
                            addNewReview({
                                question: selectedQuestion,
                                ai_answer: selectedAnswer,
                                rating: rating,
                                user_review: ''
                            })
                        )
                            .then(() => {
                                dismissModal();
                                setRating(0);
                                toast.success('Review Added Successfully');
                            })
                            .catch(() => toast.error('Failed to add review'));
                    }
                }}
            />
        </Modal>
    );
}

function QuestionReviewModal({ dismissModal, rating, selectedAnswer, selectedQuestion }) {
    const [userReview, setUserReview] = useState('');
    const dispatch = useDispatch();
    return (
        <Modal modalClassName="w-1/3 flex flex-col gap-5">
            <div className="flex w-full items-center justify-end">
                <div onClick={() => dismissModal()}>
                    <CloseButton />
                </div>
            </div>
            <p className="my-5 text-lg font-bold">ما هي اقتراحاتك لتحسين تجربتك؟</p>
            <textarea
                name="user_review"
                id="user_review"
                className="w-full"
                value={userReview}
                onChange={(e) => setUserReview(e.target.value)}></textarea>
            <Button
                text={'ارسال'}
                onClick={() => {
                    // console.log(rating, selectedAnswer, selectedQuestion, userReview);
                    dispatch(
                        addNewReview({
                            question: selectedQuestion,
                            ai_answer: selectedAnswer,
                            rating: rating,
                            user_review: userReview
                        })
                    )
                        .then(() => {
                            dismissModal();
                            toast.success('Review Added Successfully');
                        })
                        .catch(() => toast.error('Failed to add review'));
                }}
                className="mt-3"
            />
        </Modal>
    );
}

function UserMessage({ content }) {
    return (
        <>
            <div className="flex w-full justify-end">
                <div className="w-fit">
                    <img src="/images/Profile Image(1).png" alt="User Profile" />
                </div>
            </div>
            <div className="flex w-full justify-end pr-8">
                <p className="bg-aiChatColor rounded-l-4xl rounded-b-4xl w-fit px-3 py-2 text-right">
                    {content}
                </p>
            </div>
        </>
    );
}

function AIMessage({
    chatId,
    aiMsg,
    showRatingModal,
    selectedQuestion,
    index,
    messages,
    setSelectedAnswer
}) {
    const [showQuestions, setShowQuestions] = useState(false);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    return (
        <>
            <TransparentLogo />
            <div className="w-fit pl-8">
                {/* <p className="bg-aiChatColor rounded-r-4xl rounded-b-4xl w-fit px-3 py-2">
                    {aiMsg.content}
                </p> */}
                <Markdown
                    // remarkPlugins={[remarkGfm]}
                    className={`bg-aiChatColor rounded-r-4xl rounded-b-4xl prose dark:prose-invert prose-headings:text-slate-700 dark:prose-headings:text-white prose-p:text-slate-700 dark:prose-p:text-white prose-li:text-slate-700 dark:prose-li:text-white w-fit px-3 py-2 text-right`}>
                    {aiMsg.content}
                </Markdown>
                <div className="mt-2 flex flex-col items-center gap-2">
                    <div
                        className="flex cursor-pointer items-center gap-2"
                        onClick={() => setShowQuestions((state) => !state)}>
                        <img src="/images/Ellipse 5.png" className="w-3" alt="Ellipse" />
                        <img src="/images/Ellipse 5.png" className="w-3" alt="Ellipse" />
                        <img src="/images/Ellipse 5.png" className="w-3" alt="Ellipse" />
                    </div>
                    {showQuestions && (
                        <div className="grid grid-cols-2 gap-4">
                            <Button
                                onClick={() => {
                                    showRatingModal(true);
                                    selectedQuestion(messages[index].content);
                                    setSelectedAnswer(aiMsg.content);
                                    // console.log(content, messages[index].content);
                                }}
                                className="w-fit px-5"
                                text={'تقييم الاجابة'}
                            />
                            <Button
                                className="w-fit px-5"
                                onClick={() => {
                                    dispatch(
                                        addNewQuestion({
                                            question: messages[index].content,
                                            ai_answer: aiMsg.content
                                        })
                                    )
                                        .then(() => {
                                            toast.success('Question added successfully');
                                        })
                                        .catch(() => {
                                            toast.error('Failed to add new question');
                                        });
                                }}
                                text={'مساعدة اكثر'}
                            />
                            <Button
                                className="w-fit px-5"
                                onClick={() => {
                                    dispatch(clearConversation(chatId))
                                        .then(() => {
                                            toast.success('Chat cleared successfully');
                                            navigate('/admin');
                                        })
                                        .catch(() => {
                                            toast.error('Failed to clear chat');
                                        });
                                }}
                                text={'انهاء المحادثة'}
                            />
                            <Button
                                className="w-fit px-5"
                                onClick={() => {
                                    if (!aiMsg.rag_reference) {
                                        toast.error('No reference for this');
                                        return;
                                    }
                                    downloadPdf(aiMsg.rag_reference, 'Rag Reference');
                                }}
                                text={'انظر المرجع'}
                            />
                        </div>
                    )}
                </div>
            </div>
        </>
    );
}

const StarRating = ({ rating, setRating }) => {
    // Selected rating
    const [hover, setHover] = useState(0); // Hovered rating

    return (
        <div className="flex items-center justify-center">
            {/* Array of 5 stars */}
            {[...Array(5)].map((_, index) => {
                const starValue = index + 1; // Ratings start from 1

                return (
                    <svg
                        key={index}
                        xmlns="http://www.w3.org/2000/svg"
                        fill={starValue <= (hover || rating) ? 'gold' : 'gray'}
                        viewBox="0 0 24 24"
                        strokeWidth="1.5"
                        stroke="currentColor"
                        className="h-8 w-8 cursor-pointer"
                        onMouseEnter={() => setHover(starValue)}
                        onMouseLeave={() => setHover(0)}
                        onClick={() => setRating(starValue)}>
                        <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"
                        />
                    </svg>
                );
            })}
        </div>
    );
};
