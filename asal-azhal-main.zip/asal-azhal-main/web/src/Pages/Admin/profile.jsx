import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getUserProfile, updateUserProfile, deleteUserAccount } from '../../store/authSlice';
import { useForm } from 'react-hook-form';
import Button from '../../components/buttons/buttons';
import Modal from '../../components/Modal/modal';
import ChevronLeft from '../../components/icons/ChevronLeft';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';

import PropTypes from 'prop-types';

const DeleteModal = ({ isOpen, onClose, handleDelete }) => {
    return (
        <Modal isOpen={isOpen} onClose={onClose}>
            <div className="flex flex-col gap-5">
                <p className="text-center text-xl font-bold">هل انت متأكد من حذف حسابك؟</p>
                <div className="flex flex-row gap-5">
                    <Button text={'نعم'} className={`w-full`} onClick={handleDelete} />
                    <Button text={'لا'} className={`w-full`} onClick={onClose} />
                </div>
            </div>
        </Modal>
    );
};

DeleteModal.propTypes = {
    isOpen: PropTypes.bool.isRequired,
    onClose: PropTypes.func.isRequired,
    handleDelete: PropTypes.func.isRequired
};

export default function Profile() {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { userProfile } = useSelector((state) => state.auth);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

    useEffect(() => {
        dispatch(getUserProfile());
    }, [dispatch]);

    const {
        register,
        reset,
        watch,
        formState: { errors },
        handleSubmit
    } = useForm({
        defaultValues: {
            name: '',
            email: ''
        }
    });

    useEffect(() => {
        if (userProfile) {
            reset({
                name: userProfile.name || '',
                email: userProfile.email || ''
            });
        }
    }, [userProfile, reset]);

    const onSubmit = (data) => {
        const { name } = data;

        dispatch(updateUserProfile({ name: name }))
            .then(() => {
                dispatch(getUserProfile());
                toast.success('Name changed succesfully');
            })
            .catch((error) => toast.error(error.message));
    };

    const handleDelete = () => {
        dispatch(deleteUserAccount())
            .then(() => {
                toast.success('Account deleted successfully');
                navigate('/');
            })
            .catch((error) => toast.error(error.message));
    };

    return (
        <>
            {/* {Implement Loader here after merge} */}
            <div className="flex h-full w-full items-center justify-center">
                <div className="rounded-4xl flex w-2/3 flex-col bg-white p-10">
                    <div className="mb-5 flex items-center justify-between">
                        <ChevronLeft color="black" onClick={() => navigate(-1)} />
                        <p className="text-center text-xl font-bold">الملف الشخصي</p>
                    </div>
                    <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-5">
                        <fieldset className="flex w-full flex-col gap-2 text-right">
                            <label htmlFor="name">اسم</label>
                            <input
                                className="w-full rounded-lg border border-black bg-white px-2 py-2"
                                type="text"
                                {...register('name', { required: 'Please enter a name' })}
                                name="name"
                                id="name"
                                dir="rtl"
                            />
                            {errors.name && (
                                <span className="text-sm italic text-red-600">
                                    {errors.name?.message}
                                </span>
                            )}
                        </fieldset>
                        <fieldset className="flex w-full flex-col gap-2 text-right">
                            <label htmlFor="email">بريد إلكتروني</label>
                            <input
                                className="w-full cursor-not-allowed rounded-lg border border-black bg-slate-200 px-2 py-2"
                                type="text"
                                disabled
                                {...register('email')}
                                name="email"
                                id="email"
                                dir="rtl"
                            />
                        </fieldset>
                        <div className="flex flex-row gap-5">
                            <Button
                                text={'حذف الحساب'}
                                className={`w-full`}
                                onClick={(e) => {
                                    e.preventDefault();
                                    setIsDeleteModalOpen(true);
                                }}
                            />
                            <Button
                                text={'تعديل الملف الشخصي'}
                                disabled={watch('name') === userProfile?.name}
                                className={`w-full ${watch('name') === userProfile?.name ? 'cursor-not-allowed' : ''}`}
                                onClick={() => {}}
                            />
                        </div>
                    </form>
                </div>
            </div>
            {isDeleteModalOpen && (
                <DeleteModal
                    isOpen={isDeleteModalOpen}
                    onClose={() => setIsDeleteModalOpen(false)}
                    handleDelete={handleDelete}
                />
            )}
        </>
    );
}
