import { useNavigate } from 'react-router-dom';
import ChevronLeft from '../../components/icons/ChevronLeft';
import ReviewIcon from '../../components/icons/ReviewIcons';
import TransparentLogo from '../../components/icons/transparent logo';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect } from 'react';
import { fetchReviews } from '../../store/reviewSlice';
export default function AdminReview() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const { reviews } = useSelector((state) => state.review);

    const { userProfile } = useSelector((state) => state.auth);

    useEffect(() => console.log(reviews), [reviews]);

    useEffect(() => {
        dispatch(fetchReviews());
    }, [dispatch]);

    const toArabicNumerals = (num) => {
        const arabicNumerals = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
        return num
            .toString()
            .split('')
            .map((digit) => arabicNumerals[digit])
            .join('');
    };

    return (
        <>
            <main className="h-lvh w-full bg-white">
                <div className="flex w-full items-center justify-between px-10">
                    <TransparentLogo />
                    <span className="text-xl font-bold">
                        اهلًا {userProfile?.name || 'admin'} !
                    </span>
                </div>
                <hr />
                <div className="mt-5 flex w-full items-center justify-between px-10">
                    <ChevronLeft
                        color="black"
                        onClick={() => {
                            navigate(-1);
                        }}
                    />
                    <ReviewIcon />
                </div>
                <table className="my-10 w-full table-auto">
                    <thead>
                        <tr className="">
                            <th className="w-4/12 border border-y-black py-4">الجواب</th>
                            <th className="w-3/12 border border-y-black py-4">السؤال</th>
                            <th className="w-2/12 border border-y-black py-4">الرأي</th>
                            <th className="w-1/12 border border-y-black py-4">التقييم</th>
                            <th className="w-1/12 border border-y-black py-4">التاريخ والوقت</th>
                            <th className="w-1/12 border border-y-black py-4">رقم</th>
                        </tr>
                    </thead>
                    <tbody>
                        {/* {faqs.length > 0 &&
                            faqs.map((faq, idx) => {
                                return (
                                    <tr key={idx}>
                                        <td
                                            className="w-fit border py-2"
                                            onClick={() => {
                                                setEditFaq(faq);
                                                setShowEditModal(true);
                                            }}>
                                            <EditIcon2 />
                                        </td>
                                        <td className="border py-2">{faq.question}</td>
                                        <td className="border py-2">{faq.answer}</td>
                                        <td className="border py-2">{idx + 1}</td>
                                    </tr>
                                );
                            })} */}
                        {reviews.length > 0 &&
                            reviews.map((review, idx) => {
                                return (
                                    <tr key={idx} className="text-right">
                                        <td className="border px-2 py-2">{review.ai_answer}</td>
                                        <td className="border px-2 py-2">{review.question}</td>
                                        <td className="border px-2 py-2">{review.user_review}</td>
                                        <td className="border px-2 py-2 text-center">
                                            {review.rating}
                                        </td>
                                        <td className="border px-2 py-2 text-center">
                                            {new Date(review.updated_at).toLocaleDateString(
                                                'ar-SA'
                                            )}
                                        </td>
                                        <td className="border px-2 py-2 text-center">
                                            {toArabicNumerals(idx + 1)}
                                        </td>
                                    </tr>
                                );
                            })}
                    </tbody>
                </table>
                {reviews.length === 0 && (
                    <div className="w-full text-center text-xl font-bold">
                        لم يتم العثور على تعليقات
                    </div>
                )}
            </main>
        </>
    );
}
