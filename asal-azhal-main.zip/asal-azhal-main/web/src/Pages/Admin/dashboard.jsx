import DashboardLayout from '../../components/dashboard/layout';
import UserIcon from '../../components/icons/UserIcon';
import DocumentsIcon1 from '../../components/icons/DocumentsIcon';
import ReviewIcon from '../../components/icons/ReviewIcons';
import { FaqIcon } from '../../components/icons/FaqIcon';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect } from 'react';
import { getUserProfile } from '../../store/authSlice';
import ChatIcon from '../../components/icons/ChatIcon';

export default function AdminDashboard() {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(getUserProfile());
    }, [dispatch]);

    const userProfile = useSelector((state) => state.auth.userProfile);
    const list = [
        {
            name: 'الملف الشخصي',
            icon: <UserIcon />,
            link: '/profile'
        },
        {
            name: 'المستندات',
            icon: <DocumentsIcon1 />,
            link: '/admin/documents'
        },
        {
            name: 'التقييم والاراء',
            icon: <ReviewIcon />,
            link: '/admin/review'
        },
        {
            name: 'الاسئلة الشائعة',
            icon: <FaqIcon />,
            link: '/admin/faqs'
        },
        {
            name: 'بدء محادثة',
            icon: <ChatIcon />,
            link: '/admin/chat'
        }
    ];
    return (
        <>
            <div className="flex h-full w-full items-center justify-center">
                {userProfile && (
                    <DashboardLayout title={`اهلًا ${userProfile.name} !`} listOfIcons={list} />
                )}
            </div>
        </>
    );
}
