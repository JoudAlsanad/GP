import React from 'react';
import ReactDOM from 'react-dom/client';
// import App from './App';
import './index.css';
import { Provider } from 'react-redux';
import store from './store';
// import { Toaster } from 'react-hot-toast'
import { CustomToaster as Toaster } from './components/Toasts/CustomToaster.jsx';
import { GoogleOAuthProvider } from '@react-oauth/google';

import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import Start from './Pages/Start/start.jsx';
import Login from './Pages/Auth/login/login.jsx';
import SignUp from './Pages/Auth/sign up/sign up.jsx';
import Registered from './Pages/Auth/success registered/registered.jsx';
import AdminDashboard from './Pages/Admin/dashboard.jsx';
import Home from './Pages/home.jsx';
import AdminDocuments from './Pages/Admin/documents.jsx';
import AdminFaq from './Pages/Admin/faq.jsx';
import { ProtectedRoute, UnAuthenticatedRoute } from './components/Auth/RouteGuards.jsx';
import Profile from './Pages/Admin/profile.jsx';
import AdminReview from './Pages/Admin/review.jsx';
import EmployeeDashboard from './Pages/Employee/dashboard.jsx';
import EmployeeQuestions from './Pages/Employee/questions.jsx';
import StudentQuestions from './Pages/Student/questions.jsx';
import StudentDashboard from './Pages/Student/dashboard.jsx';
import StudentChat from './Pages/Student/chat.jsx';
import GuestLogin from './Pages/Auth/guest/login.jsx';
import SetPassword from './Pages/Auth/setPassword/index.jsx';
import GuestDashboard from './Pages/Guest/dashboard.jsx';
import GuestChat from './Pages/Guest/chat.jsx';
import AdminChat from './Pages/Admin/chat.jsx';
import Loader from './components/Loader/Loader.jsx';
import GuestQuestions from './Pages/Guest/questions.jsx';

const router = createBrowserRouter([
    {
        path: '/',
        element: <Home />,
        children: [
            {
                path: '/',
                element: (
                    <UnAuthenticatedRoute>
                        <Start />
                    </UnAuthenticatedRoute>
                )
            },
            {
                path: '/login',
                element: (
                    <UnAuthenticatedRoute>
                        <Login />
                    </UnAuthenticatedRoute>
                )
            },
            {
                path: '/set-password',
                element: (
                    <UnAuthenticatedRoute>
                        <SetPassword />
                    </UnAuthenticatedRoute>
                )
            },
            {
                path: '/guest-login',
                element: (
                    <UnAuthenticatedRoute>
                        <GuestLogin />
                    </UnAuthenticatedRoute>
                )
            },
            {
                path: '/signup',
                element: (
                    <UnAuthenticatedRoute>
                        <SignUp />
                    </UnAuthenticatedRoute>
                )
            },
            {
                path: '/registered',
                element: (
                    <ProtectedRoute allowedRoles={['school_admin', 'student', 'employee']}>
                        <Registered />
                    </ProtectedRoute>
                )
            },
            {
                path: '/admin',
                element: (
                    <ProtectedRoute allowedRoles={['school_admin']}>
                        <AdminDashboard />
                    </ProtectedRoute>
                ),
                children: []
            },
            {
                path: '/profile',
                element: <Profile />
            },
            {
                path: '/employee',
                element: (
                    <ProtectedRoute allowedRoles={['employee']}>
                        <EmployeeDashboard />
                    </ProtectedRoute>
                )
            },
            {
                path: '/student',
                element: (
                    <ProtectedRoute allowedRoles={['student']}>
                        <StudentDashboard />
                    </ProtectedRoute>
                )
            },
            {
                path: '/student/chat',
                element: (
                    <ProtectedRoute allowedRoles={['student']}>
                        <StudentChat />
                    </ProtectedRoute>
                )
            },
            {
                path: '/guest',
                element: (
                    <ProtectedRoute allowedRoles={['guest']}>
                        <GuestDashboard />
                    </ProtectedRoute>
                )
            },
            {
                path: '/guest/chat',
                element: (
                    <ProtectedRoute allowedRoles={['guest']}>
                        <GuestChat />
                    </ProtectedRoute>
                )
            },
            {
                path: '/admin/chat',
                element: (
                    <ProtectedRoute allowedRoles={['school_admin']}>
                        <AdminChat />
                    </ProtectedRoute>
                )
            }
        ]
    },
    {
        path: '/admin/documents',
        element: (
            <ProtectedRoute allowedRoles={['school_admin']}>
                <AdminDocuments />
            </ProtectedRoute>
        )
    },
    {
        path: '/admin/faqs',
        element: (
            <ProtectedRoute allowedRoles={['school_admin']}>
                <AdminFaq />
            </ProtectedRoute>
        )
    },
    {
        path: '/admin/review',
        element: (
            <ProtectedRoute allowedRoles={['school_admin']}>
                <AdminReview />
            </ProtectedRoute>
        )
    },

    {
        path: '/employee/questions',
        element: (
            <ProtectedRoute allowedRoles={['employee']}>
                <EmployeeQuestions />
            </ProtectedRoute>
        )
    },
    {
        path: '/student/questions',
        element: (
            <ProtectedRoute allowedRoles={['student']}>
                <StudentQuestions />
            </ProtectedRoute>
        )
    },
    {
        path: '/guest/questions',
        element: (
            <ProtectedRoute allowedRoles={['guest']}>
                <GuestQuestions />
            </ProtectedRoute>
        )
    },
    { path: '/not-authorized', element: <div>Not Authorized</div> }
]);

ReactDOM.createRoot(document.getElementById('root')).render(
    <React.StrictMode>
        <Provider store={store}>
            <GoogleOAuthProvider clientId="603088417164-ssmjui8pmrqkq01sdpu96n1i19rr6803.apps.googleusercontent.com">
                <Loader />
                <RouterProvider router={router} />
                <Toaster
                    toastOptions={{
                        duration: 1000
                    }}
                />
            </GoogleOAuthProvider>
        </Provider>
    </React.StrictMode>
);
