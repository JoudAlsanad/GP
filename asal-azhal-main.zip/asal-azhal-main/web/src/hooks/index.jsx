import { useQuery } from "./useQuery";

export default {
  useQuery,
};
