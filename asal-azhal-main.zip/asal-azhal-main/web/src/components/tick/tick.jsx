export default function Tick() {
  return (
    <svg
      width="209"
      height="217"
      viewBox="0 0 209 217"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M186.738 49.7291L73.2837 167.271L21.7137 113.843"
        stroke="url(#paint0_linear_64_1927)"
        strokeWidth="20.0376"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <defs>
        <linearGradient
          id="paint0_linear_64_1927"
          x1="104.226"
          y1="49.7291"
          x2="104.226"
          y2="167.271"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#43A7EF" />
          <stop offset="0.475" stopColor="#845AFA" />
          <stop offset="1" stopColor="#C24EF0" />
        </linearGradient>
      </defs>
    </svg>
  );
}
