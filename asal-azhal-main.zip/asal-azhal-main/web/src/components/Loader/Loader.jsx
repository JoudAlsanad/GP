/* eslint-disable react/prop-types */
import { InfinitySpin } from 'react-loader-spinner';
import classNames from 'classnames';
import { useSelector } from 'react-redux';

const Loader = ({ containerClassName, loading, loaderWidth = 200, loaderColor = '#845AFA' }) => {
    const authLoading = useSelector((state) => state.auth.loading);
    const docLoading = useSelector((state) => state.doc.loading);
    const faqLoading = useSelector((state) => state.faq.loading);
    const loadingState = loading || authLoading || docLoading || faqLoading;
    return (
        <>
            {loadingState && (
                <div
                    className={classNames(
                        'bg-blur-50 fixed left-0 top-0 z-[400] flex h-full w-full items-center justify-center bg-slate-100 bg-opacity-90 dark:bg-slate-950 dark:bg-opacity-90',
                        containerClassName
                    )}>
                    <InfinitySpin
                        visible={loadingState}
                        width={loaderWidth}
                        color={loaderColor}
                        ariaLabel="infinity-spin-loading"
                    />
                </div>
            )}
        </>
    );
};

export default Loader;
