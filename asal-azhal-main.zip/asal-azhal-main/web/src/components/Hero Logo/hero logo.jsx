export default function HeroLogo() {
    return (
        <>
            <div className="fixed top-1/2 h-[80%] w-full -translate-y-[50%] translate-x-[60%] rounded-full bg-[rgba(255,255,255,0.4)]">
                <div className="relative flex h-full w-1/2 items-center justify-center">
                    <img
                        src="\images\logo text.png"
                        alt="Start Image"
                        className="cover relative w-1/2"
                    />
                </div>
            </div>
        </>
    );
}
