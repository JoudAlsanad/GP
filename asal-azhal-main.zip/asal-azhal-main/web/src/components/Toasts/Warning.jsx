import React from "react";
import { ExclamationTriangleIcon } from "@heroicons/react/24/outline";

const Warning = ({children, className}) => {    
    return (
        <div className={`bg-yellow-100 dark:bg-yellow-800 text-yellow-800 dark:text-yellow-100 p-4 rounded-md shadow-md flex flex-row items-center justify-center pointer-events-auto ${className}`}>
            <ExclamationTriangleIcon className="h-5 w-5 text-yellow-500 dark:text-yellow-300 mr-2" />
            {children}
        </div>
    );
}

export default Warning;
