import classNames from 'classnames';

// eslint-disable-next-line react/prop-types
export default function Button({ text, onClick = () => {}, className = '', disabled = false }) {
    const buttonClasses = classNames(
        'rounded-xl px-2 py-2 text-white bg-gradient-to-r from-gradStart via-gradMid to-gradEnd',
        className
    );

    return (
        <>
            <button className={buttonClasses} onClick={onClick} disabled={disabled}>
                {text}
            </button>
        </>
    );
}
