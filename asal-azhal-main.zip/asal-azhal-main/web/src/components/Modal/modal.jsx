/* eslint-disable react/prop-types */
import classNames from 'classnames';
export default function Modal({ children, containerClassName, modalClassName }) {
    const containerClassNames = classNames(
        'fixed bottom-0 left-0 right-0 top-0 z-[200] flex items-center justify-center bg-[rgba(0,0,0,0.5)]',
        containerClassName
    );
    const modalClassNames = classNames(
        'flex flex-col items-center justify-center rounded-xl bg-white p-10',
        modalClassName
    );
    return (
        <>
            <div className={containerClassNames}>
                <div className={modalClassNames}>{children}</div>
            </div>
        </>
    );
}
