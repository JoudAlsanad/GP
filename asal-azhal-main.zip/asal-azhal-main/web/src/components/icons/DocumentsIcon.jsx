export default function DocumentsIcon1() {
    return (
        <svg
            width="45"
            height="57"
            viewBox="0 0 45 57"
            fill="none"
            xmlns="http://www.w3.org/2000/svg">
            <rect width="45" height="57" rx="6" fill="url(#paint0_linear_86_1433)" />
            <rect x="5" y="5" width="35" height="47" rx="3" fill="white" />
            <defs>
                <linearGradient
                    id="paint0_linear_86_1433"
                    x1="22.5"
                    y1="0"
                    x2="22.5"
                    y2="57"
                    gradientUnits="userSpaceOnUse">
                    <stop stopColor="#C24EF0" />
                    <stop offset="0.51" stopColor="#845AFA" />
                    <stop offset="1" stopColor="#43A7EF" />
                </linearGradient>
            </defs>
        </svg>
    );
}

export function DocumentsIcon2() {
    return (
        <div className="flex items-center gap-3">
            <span>المستندات</span>
            <img src="\images\documentsIcon2.png" alt="documents icon" />
        </div>
    );
}
