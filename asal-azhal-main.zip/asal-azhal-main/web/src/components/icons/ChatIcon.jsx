export default function ChatIcon() {
    return (
        <svg
            width="46"
            height="52"
            viewBox="0 0 46 52"
            fill="none"
            xmlns="http://www.w3.org/2000/svg">
            <path
                d="M4 46.5214V8.91876C4 6.2022 5.89035 4 8.22222 4H37.7778C40.1097 4 42 6.2022 42 8.91876V33.5126C42 36.2292 40.1097 38.4313 37.7778 38.4313H14.4737C13.1911 38.4313 11.978 39.1106 11.1767 40.2773L6.25576 47.4432C5.50778 48.5325 4 47.9164 4 46.5214Z"
                stroke="url(#paint0_linear_69_2355)"
                strokeWidth="7.36809"
            />
            <defs>
                <linearGradient
                    id="paint0_linear_69_2355"
                    x1="23"
                    y1="4"
                    x2="23"
                    y2="48"
                    gradientUnits="userSpaceOnUse">
                    <stop stopColor="#C24EF0" />
                    <stop offset="0.51" stopColor="#845AFA" />
                    <stop offset="1" stopColor="#43A7EF" />
                </linearGradient>
            </defs>
        </svg>
    );
}
