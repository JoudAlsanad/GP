export default function ReviewIcon() {
    return (
        <svg
            width="48"
            height="47"
            viewBox="0 0 48 47"
            fill="none"
            xmlns="http://www.w3.org/2000/svg">
            <path
                d="M46 23.5C46 35.3346 36.1902 45 24 45C11.8098 45 2 35.3346 2 23.5C2 11.6654 11.8098 2 24 2C36.1902 2 46 11.6654 46 23.5Z"
                fill="white"
                stroke="url(#paint0_linear_88_1583)"
                strokeWidth="4"
            />
            <path
                d="M33.8531 21.5892L34.7998 18.7363L35.7465 21.5892C35.8347 21.8551 36.0833 22.0345 36.3634 22.0345H39.4104L36.9572 23.7797C36.7246 23.9452 36.6272 24.2431 36.7171 24.5141L37.6572 27.3473L35.1766 25.5826C34.951 25.4221 34.6486 25.4221 34.423 25.5826L31.9424 27.3473L32.8825 24.5141C32.9725 24.2431 32.875 23.9452 32.6424 23.7797L30.1892 22.0345H33.2362C33.5163 22.0345 33.7649 21.8551 33.8531 21.5892Z"
                fill="white"
                stroke="url(#paint1_linear_88_1583)"
                strokeWidth="0.7"
            />
            <path
                d="M12.2535 21.5892L13.2002 18.7363L14.1469 21.5892C14.2351 21.8551 14.4837 22.0345 14.7638 22.0345H17.8108L15.3576 23.7797C15.125 23.9452 15.0275 24.2431 15.1175 24.5141L16.0576 27.3473L13.577 25.5826C13.3514 25.4221 13.049 25.4221 12.8234 25.5826L10.3428 27.3473L11.2829 24.5141C11.3728 24.2431 11.2754 23.9452 11.0428 23.7797L8.58962 22.0345H11.6366C11.9167 22.0345 12.1653 21.8551 12.2535 21.5892Z"
                fill="white"
                stroke="url(#paint2_linear_88_1583)"
                strokeWidth="0.7"
            />
            <path
                d="M23.0533 21.5892L24 18.7363L24.9467 21.5892C25.0349 21.8551 25.2835 22.0345 25.5636 22.0345H28.6106L26.1574 23.7797C25.9248 23.9452 25.8274 24.2431 25.9173 24.5141L26.8574 27.3473L24.3768 25.5826C24.1512 25.4221 23.8488 25.4221 23.6232 25.5826L21.1426 27.3473L22.0827 24.5141C22.1726 24.2431 22.0752 23.9452 21.8426 23.7797L19.3894 22.0345H22.4364C22.7165 22.0345 22.9651 21.8551 23.0533 21.5892Z"
                fill="white"
                stroke="url(#paint3_linear_88_1583)"
                strokeWidth="0.7"
            />
            <defs>
                <linearGradient
                    id="paint0_linear_88_1583"
                    x1="24"
                    y1="0"
                    x2="24"
                    y2="47"
                    gradientUnits="userSpaceOnUse">
                    <stop stopColor="#C24EF0" />
                    <stop offset="0.5" stopColor="#845AFA" />
                    <stop offset="1" stopColor="#43A7EF" />
                </linearGradient>
                <linearGradient
                    id="paint1_linear_88_1583"
                    x1="34.7998"
                    y1="17.625"
                    x2="34.7998"
                    y2="29.375"
                    gradientUnits="userSpaceOnUse">
                    <stop stopColor="#C24EF0" />
                    <stop offset="0.525" stopColor="#845AFA" />
                    <stop offset="1" stopColor="#43A7EF" />
                </linearGradient>
                <linearGradient
                    id="paint2_linear_88_1583"
                    x1="13.2002"
                    y1="17.625"
                    x2="13.2002"
                    y2="29.375"
                    gradientUnits="userSpaceOnUse">
                    <stop stopColor="#C24EF0" />
                    <stop offset="0.525" stopColor="#845AFA" />
                    <stop offset="1" stopColor="#43A7EF" />
                </linearGradient>
                <linearGradient
                    id="paint3_linear_88_1583"
                    x1="24"
                    y1="17.625"
                    x2="24"
                    y2="29.375"
                    gradientUnits="userSpaceOnUse">
                    <stop stopColor="#C24EF0" />
                    <stop offset="0.525" stopColor="#845AFA" />
                    <stop offset="1" stopColor="#43A7EF" />
                </linearGradient>
            </defs>
        </svg>
    );
}

export function ReviewIconText() {
    return (
        <div className="flex items-center gap-3">
            <span>التقييم و الأراء</span>
            <ReviewIcon />
        </div>
    );
}
