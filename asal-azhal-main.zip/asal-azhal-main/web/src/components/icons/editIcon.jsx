/* eslint-disable react/prop-types */
import classNames from 'classnames';

export default function EditIcon({ className, onClick = () => {} }) {
    const classes = classNames(
        'from-gradStart via-gradMid to-gradEnd rounded-xl bg-gradient-to-b px-3 py-4',
        className
    );
    return (
        <div onClick={onClick} className={classes}>
            <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M5.18832 18.4285C5.2419 18.4285 5.29547 18.4231 5.34904 18.4151L9.85439 17.6249C9.90797 17.6142 9.95886 17.5901 9.99636 17.5499L21.3508 6.19547C21.3757 6.17069 21.3954 6.14125 21.4088 6.10885C21.4222 6.07644 21.4292 6.04171 21.4292 6.00663C21.4292 5.97155 21.4222 5.93681 21.4088 5.90441C21.3954 5.872 21.3757 5.84257 21.3508 5.81779L16.899 1.36332C16.8481 1.31243 16.7812 1.28564 16.7089 1.28564C16.6365 1.28564 16.5696 1.31243 16.5187 1.36332L5.16422 12.7178C5.12404 12.758 5.09993 12.8062 5.08922 12.8598L4.29904 17.3651C4.27298 17.5086 4.28229 17.6563 4.32616 17.7954C4.37004 17.9345 4.44715 18.0608 4.55082 18.1633C4.72761 18.3348 4.94993 18.4285 5.18832 18.4285ZM6.99368 13.7571L16.7089 4.04457L18.6723 6.00797L8.95707 15.7205L6.57582 16.141L6.99368 13.7571ZM21.8571 20.6785H2.14279C1.66868 20.6785 1.28564 21.0615 1.28564 21.5356V22.4999C1.28564 22.6178 1.38207 22.7142 1.49993 22.7142H22.4999C22.6178 22.7142 22.7142 22.6178 22.7142 22.4999V21.5356C22.7142 21.0615 22.3312 20.6785 21.8571 20.6785Z"
                    fill="white"
                />
            </svg>
        </div>
    );
}

export function EditIcon2(className) {
    const classes = classNames('h-6 w-6', className);
    return <img src="/images/EditOutlined.png" alt="Edit Icon" className={classes} />;
}
