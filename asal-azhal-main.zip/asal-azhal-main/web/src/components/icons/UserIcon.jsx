export default function UserIcon() {
  return (
    <svg
      width="53"
      height="53"
      viewBox="0 0 53 53"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M0 0H53V53H0V0Z" fill="white" fillOpacity="0.01" />
      <path
        d="M26.4998 22.0832C31.3784 22.0832 35.3332 18.1284 35.3332 13.2498C35.3332 8.37132 31.3784 4.4165 26.4998 4.4165C21.6213 4.4165 17.6665 8.37132 17.6665 13.2498C17.6665 18.1284 21.6213 22.0832 26.4998 22.0832Z"
        stroke="url(#paint0_linear_86_1324)"
        strokeWidth="7.05188"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M46.375 48.5833C46.375 37.6066 37.4766 28.7083 26.5 28.7083C15.5234 28.7083 6.625 37.6066 6.625 48.5833"
        stroke="url(#paint1_linear_86_1324)"
        strokeWidth="7.05188"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <defs>
        <linearGradient
          id="paint0_linear_86_1324"
          x1="26.4998"
          y1="4.4165"
          x2="26.4998"
          y2="22.0832"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#C24EF0" />
          <stop offset="0.52" stopColor="#845AFA" />
          <stop offset="1" stopColor="#43A7EF" />
        </linearGradient>
        <linearGradient
          id="paint1_linear_86_1324"
          x1="26.5"
          y1="28.7083"
          x2="26.5"
          y2="48.5833"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#C24EF0" />
          <stop offset="0.52" stopColor="#845AFA" />
          <stop offset="1" stopColor="#43A7EF" />
        </linearGradient>
      </defs>
    </svg>
  );
}
