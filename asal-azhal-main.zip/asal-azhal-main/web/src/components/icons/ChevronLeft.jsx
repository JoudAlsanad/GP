/* eslint-disable react/prop-types */
export default function ChevronLeft({ color = 'white', onClick = () => {} }) {
    return (
        <svg
            onClick={onClick}
            className="cursor-pointer"
            width="37"
            height="39"
            viewBox="0 0 37 39"
            fill="none"
            xmlns="http://www.w3.org/2000/svg">
            <path
                d="M14.2977 19.5009L25.1048 8.10961C25.4058 7.79231 25.4058 7.27786 25.1048 6.96056L24.2327 6.04132C23.9317 5.72402 23.4436 5.72402 23.1426 6.04132L10.9183 18.9264C10.6172 19.2437 10.6172 19.7582 10.9183 20.0755L23.1426 32.9606C23.4436 33.2779 23.9317 33.2779 24.2327 32.9606L25.1048 32.0413C25.4058 31.724 25.4058 31.2096 25.1048 30.8923L14.2977 19.5009Z"
                fill={color}
            />
        </svg>
    );
}
