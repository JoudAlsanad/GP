export default function TransparentLogo() {
  return (
    <>
      <div className="flex h-16 w-16 items-center justify-center rounded-full">
        <img src={"/images/Profile Image.png"} className="cover" />
      </div>
    </>
  );
}
