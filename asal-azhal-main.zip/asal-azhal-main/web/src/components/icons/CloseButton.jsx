export default function CloseButton() {
    return (
        <svg
            width="20"
            height="20"
            viewBox="0 0 20 20"
            fill="none"
            xmlns="http://www.w3.org/2000/svg">
            <path
                d="M10 0C4.475 0 0 4.475 0 10C0 15.525 4.475 20 10 20C15.525 20 20 15.525 20 10C20 4.475 15.525 0 10 0ZM15 13.585L13.585 15L10 11.415L6.415 15L5 13.585L8.585 10L5 6.415L6.415 5L10 8.585L13.585 5L15 6.415L11.415 10L15 13.585Z"
                fill="url(#paint0_linear_140_2968)"
            />
            <defs>
                <linearGradient
                    id="paint0_linear_140_2968"
                    x1="10"
                    y1="0"
                    x2="10"
                    y2="20"
                    gradientUnits="userSpaceOnUse">
                    <stop stopColor="#43A7EF" />
                    <stop offset="0.51" stopColor="#845AFA" />
                    <stop offset="1" stopColor="#C24EF0" />
                </linearGradient>
            </defs>
        </svg>
    );
}
