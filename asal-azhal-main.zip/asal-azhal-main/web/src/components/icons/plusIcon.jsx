/* eslint-disable react/prop-types */
export default function PlusIcon({ func = () => {} }) {
    /* eslint-disable react/prop-types */
    return (
        <div
            onClick={func}
            className="from-gradStart via-gradMid to-gradEnd rounded-xl bg-gradient-to-b p-2">
            <img src="/images/plus icon.png" alt="Plus Icon" />
        </div>
    );
}
