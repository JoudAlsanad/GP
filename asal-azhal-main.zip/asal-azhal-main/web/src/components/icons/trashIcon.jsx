/* eslint-disable react/prop-types */
export default function TrashIcon({ func = () => {} }) {
    return (
        <div
            onClick={func}
            className="from-gradStart via-gradMid to-gradEnd rounded-xl bg-gradient-to-b px-3 py-4">
            <svg
                width="21"
                height="23"
                viewBox="0 0 21 23"
                fill="none"
                xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M17.8891 10.2651V21.1516C17.8891 21.5354 17.6056 21.8465 17.2558 21.8465H3.74466C3.39488 21.8465 3.11133 21.5354 3.11133 21.1516V10.2651"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                />
                <path
                    d="M8.38916 17.2139V10.2651"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                />
                <path
                    d="M12.6108 17.2139V10.2651"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                />
                <path
                    d="M20 5.63253H14.7222M14.7222 5.63253V1.69488C14.7222 1.31111 14.4387 1 14.0889 1H6.91111C6.56133 1 6.27778 1.31111 6.27778 1.69488V5.63253M14.7222 5.63253H6.27778M1 5.63253H6.27778"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                />
            </svg>
        </div>
    );
}
