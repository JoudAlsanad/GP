/* eslint-disable react/prop-types */
import { Link, useNavigate } from 'react-router-dom';
import TransparentLogo from '../icons/transparent logo';
import Button from '../buttons/buttons';
import { useDispatch } from 'react-redux';
import { logoutUser } from '../../store/authSlice';

export default function DashboardLayout({ title, listOfIcons }) {
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const logout = () => {
        dispatch(logoutUser());
        navigate('/');
    };

    return (
        <>
            <div className="rounded-4xl flex w-[80%] flex-col bg-white p-10">
                <Button text={'تسجيل خروج'} onClick={logout} className="w-fit px-5" />
                <div className="flex w-full items-center justify-between">
                    <TransparentLogo />
                    <span className="mt-2 text-xl font-bold" dir="rtl">
                        {title}
                    </span>
                </div>
                <hr className="mb-5 mt-3" />
                <div className="flex flex-col items-end gap-5">
                    {listOfIcons.map((button, idx) => {
                        return (
                            <Link className="flex items-center gap-5" key={idx} to={button.link}>
                                <span>{button.name}</span>
                                <span className="">{button.icon}</span>
                            </Link>
                        );
                    })}
                </div>
            </div>
        </>
    );
}
