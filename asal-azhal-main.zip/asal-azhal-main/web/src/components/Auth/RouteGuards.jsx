/* eslint-disable react/prop-types */
import { Navigate } from 'react-router-dom';
import { getUserProfile } from '../../store/authSlice';
import { useDispatch } from 'react-redux';

export const ProtectedRoute = ({ children, allowedRoles }) => {
    const dispatch = useDispatch();
    const token = localStorage.getItem('token');
    if (token) {
        dispatch(getUserProfile());
    }
    const userType = localStorage.getItem('userType');

    console.log(userType, allowedRoles);

    if (!token) {
        return <Navigate to="/login" replace />;
    }

    if (allowedRoles && !allowedRoles.includes(userType)) {
        return <Navigate to="/not-authorized" replace />;
    }

    return children;
};

export function UnAuthenticatedRoute({ children }) {
    const dispatch = useDispatch();
    const token = localStorage.getItem('token');
    if (token) {
        dispatch(getUserProfile());
    }
    const userType = localStorage.getItem('userType');

    if (token && userType) {
        switch (userType) {
            case 'school_admin':
                return <Navigate to="/admin" replace />;
            case 'employee':
                return <Navigate to={'/employee'} replace />;
            case 'student':
                return <Navigate to={'/student'} replace />;
            default:
                break;
        }
    }

    return children;
}
