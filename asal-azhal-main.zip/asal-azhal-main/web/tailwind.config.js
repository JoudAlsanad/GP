/* eslint-disable no-undef */
/** @type {import('tailwindcss').Config} */
export default {
    content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
    darkMode: 'class',
    theme: {
        screens: {
            xs: '480px',
            sm: '640px',
            md: '768px',
            lg: '1024px',
            xl: '1140px',
            '2xl': '1280px'
        },
        container: {
            center: true
        },
        extend: {
            keyframes: {
                animateGradient: {
                    '0%': { 'background-position': '0% 50%' },
                    '50%': { 'background-position': '100% 50%' },
                    '100%': { 'background-position': '0% 50%' }
                }
            },
            borderRadius: {
                '4xl': '2rem'
            },
            colors: {
                transBg: 'rgba(255,255,255,0.4)',
                gradStart: '#C24EF0',
                gradMid: '#845AFA',
                gradEnd: '#43A7EF',
                aiChatColor: '#E9E9EB'
            }
        }
    },
    plugins: [
        require('@tailwindcss/forms'),
        require('@tailwindcss/typography'),
        require('@headlessui/tailwindcss'),
        require('tailwind-scrollbar')
        // ...
    ]
};
