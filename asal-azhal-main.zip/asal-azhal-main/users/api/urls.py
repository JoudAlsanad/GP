from django.urls import path, include, re_path
from .views import (
    LoginView,
    SignupView,
    UserProfileView,
    GuestLoginView,
    GoogleLoginView,
    UserRedirectView,
    DeleteUserView,
    ForgotPasswordAPIView,
    SetPasswordAPIView,
)

urlpatterns = [
    path("login", LoginView.as_view(), name="login"),
    path("signup", SignupView.as_view(), name="signup"),
    path("profile", UserProfileView.as_view(), name="profile"),
    path("delete_user", DeleteUserView.as_view(), name="delete_user"),
    path("set_password", SetPasswordAPIView.as_view(), name="set_password"),
    path("forgot_password", ForgotPasswordAPIView.as_view(), name="forgot_password"),
    path("guest_login/", GuestLoginView.as_view(), name="guest-login"),
    path("google_login/", GoogleLoginView.as_view(), name="google_login"),
    path("~redirect/", view=UserRedirectView.as_view(), name="redirect"),
]
