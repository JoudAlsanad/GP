from rest_framework import serializers

from users.models import User
from django.core.exceptions import ValidationError
from django.contrib.auth.password_validation import validate_password
from rest_framework.validators import UniqueValidator

from rest_framework.authtoken.models import Token


class EmailLoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField()

    def validate(self, attrs):
        return attrs


class UserLoginInfoSerializer(serializers.ModelSerializer):
    name = serializers.SerializerMethodField()
    email = serializers.SerializerMethodField()
    id = serializers.SerializerMethodField()
    # is_email_verified = serializers.SerializerMethodField()
    token = serializers.SerializerMethodField()

    def get_name(self, obj):
        return obj.name if obj else None

    def get_email(self, obj):
        return obj.email if obj else None

    def get_token(self, obj):
        return Token.objects.get_or_create(user=obj)[0].key

    def get_id(self, obj):
        return obj.id if obj else None

    def validate(self, obj):
        # TODO: don't allow login blocked/blacklisted user TBD
        if not obj.is_active:
            return False
        return obj

    class Meta:
        model = User
        fields = ("name", "email", "id", "token", "user_type")


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = (
            "id",
            "name",
            "email",
            "is_active",
            "user_type",
        )


class SignupSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(
        required=True,
        validators=[UniqueValidator(queryset=User.objects.all())],
    )
    password = serializers.CharField(
        write_only=True,
        required=True,
        validators=[validate_password],
    )
    confirm_password = serializers.CharField(write_only=True, required=True)
    name = serializers.CharField(required=True)

    def validate(self, data):
        if data["password"] != data["confirm_password"]:
            raise ValidationError("Passwords do not match")
        return data

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data["email"],
            email=validated_data["email"],
            password=validated_data["password"],
            name=validated_data["name"],
        )
        return user

    class Meta:
        model = User
        fields = (
            "email",
            "password",
            "confirm_password",
            "name",
        )


class UserNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["name"]
