from django.contrib.auth import authenticate, login
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.authtoken.models import Token
import secrets
from core.views import BaseAPIView
from users.models import User, LoginToken
from .serializers import (
    UserLoginInfoSerializer,
    UserSerializer,
    EmailLoginSerializer,
    SignupSerializer,
    UserNameSerializer,
)
from allauth.socialaccount.providers.google.views import GoogleOAuth2Adapter
from allauth.socialaccount.providers.oauth2.client import OAuth2Client
from dj_rest_auth.registration.views import SocialLoginView

from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import RedirectView


class LoginView(BaseAPIView):
    permission_classes = [
        # HMACPermissions
    ]
    serializer_class = EmailLoginSerializer

    def post(self, request):
        result = EmailLoginSerializer(data=request.data)
        if result.is_valid(raise_exception=True):
            email = result.validated_data.get("email", None)
            password = result.validated_data.get("password", False)
            user = authenticate(username=email, password=password)
            if user is not None:
                # A backend authenticated the credentials
                user_info = UserLoginInfoSerializer(user)
                response = {
                    "payload": user_info.data,
                    "message": "Success",
                }
            else:
                # No backend authenticated the credentials
                response = {
                    "payload": None,
                    "message": "Invalid Credentials",
                    "success": False,
                    "status_code": 400,
                }
        else:
            response = {
                "payload": None,
                "message": "Invalid Credentials",
                "success": False,
                "status_code": 400,
            }
        return self.send_success_response(**response)


class GuestLoginView(BaseAPIView):
    permission_classes = [
        # HMACPermissions
    ]

    def post(self, request):
        guest_name = request.data.get("name")
        if not guest_name:
            return self.send_bad_request_response(message="Name is required")

        # Create a guest user with the provided name
        guest_secret = f"guest_{secrets.token_hex(8)}"
        guest_user, created = User.objects.get_or_create(
            username=guest_secret,  # unique username for guest
            defaults={"name": guest_name, "user_type": "guest"},
        )
        if not created:
            return self.send_bad_request_response(message="Guest user already exists")

        # Specify the backend manually
        guest_user.backend = "django.contrib.auth.backends.ModelBackend"

        # Log in the guest user
        login(request, guest_user)

        user_info = UserLoginInfoSerializer(guest_user)
        return self.send_success_response(
            payload=user_info.data, message="Guest logged in successfully"
        )


class SignupView(BaseAPIView):
    permission_classes = [
        # HMACPermissions
    ]

    def post(self, request):
        data = request.data
        try:
            serializer = SignupSerializer(data=data)
            if serializer.is_valid(raise_exception=True):
                user = serializer.save()
                return self.send_success_response(
                    payload=UserLoginInfoSerializer(user).data,
                    message="User Signed up Successful",
                )
        except Exception as e:
            return self.send_bad_request_response(e.args[0])


class UserProfileView(BaseAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [
        TokenAuthentication,
    ]

    def get(self, request):
        user = request.user
        data = {
            "user": UserSerializer(user).data,
        }

        return self.send_response(payload=data, message="Success")

    def patch(self, request):
        user = request.user
        ser = UserNameSerializer(user, data=request.data, partial=True)
        if ser.is_valid(raise_exception=True):
            ser.save()
            return self.send_response(payload=ser.data, message="Success")

        return self.send_bad_request_response(message="Invalid Data")


class GoogleLoginView(SocialLoginView):
    permission_classes = []
    authentication_classes = []

    adapter_class = GoogleOAuth2Adapter
    callback_url = "http://localhost"
    client_class = OAuth2Client


class UserRedirectView(LoginRequiredMixin, RedirectView):
    """
    This view is needed by the dj-rest-auth-library in order to work the google login. It's a bug.
    """

    permanent = False

    def get_redirect_url(self):
        return "redirect-url"


class DeleteUserView(BaseAPIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [
        TokenAuthentication,
    ]

    def post(self, request):
        user = request.user
        user.delete()
        return self.send_response(message="User Deleted Successfully")


class ForgotPasswordAPIView(BaseAPIView):
    permission_classes = [
        # HMACPermissions
    ]
    authentication_classes = []

    def post(self, request):
        email = request.data.get("email", None)
        user = User.objects.filter(email=email, username=email).first()
        if not user:
            return self.send_bad_request_response(message="Invalid Email")
        user.send_forgot_password_email()
        response = {
            "payload": None,
            "message": "Success",
        }
        return self.send_success_response(**response)


class SetPasswordAPIView(BaseAPIView):
    permission_classes = [
        # HMACPermissions
    ]
    authentication_classes = []

    def post(self, request):
        password1 = request.data.get("password1", None)
        password2 = request.data.get("password2", None)
        login_token = request.data.get("token", None)

        login_token_obj = LoginToken.objects.filter(
            token=login_token, is_expired=False
        ).first()
        if not login_token_obj:
            return self.send_bad_request_response(message="Invalid Token")

        if password1 != password2:
            return self.send_bad_request_response(message="Password Mismatch")

        user = login_token_obj.user
        if not user:
            return self.send_bad_request_response(message="Invalid Token")

        # if user.has_usable_password():
        #     return self.send_bad_request_response(message="Password Already Set")

        if user:
            user.set_password(password1)
            user.save(update_fields=["password"])
            login_token_obj.is_expired = True
            login_token_obj.save(update_fields=["is_expired"])
            user_info = UserLoginInfoSerializer(user)
            response = {
                "payload": user_info.data,
                "message": "Success",
            }
            return self.send_success_response(**response)

        return self.send_bad_request_response(message="Invalid Data")
