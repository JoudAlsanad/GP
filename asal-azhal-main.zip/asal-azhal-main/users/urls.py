from django.urls import path, include, re_path

app_name = "users"
urlpatterns = [
    path("api/", include("users.api.urls")),
]
