import uuid
from django.contrib.auth.models import AbstractUser
from django.contrib.sites.shortcuts import get_current_site
from django.db.models import CharField
from django.db import models
from django.urls import reverse
from django.utils.translation import gettext_lazy as _
from core.models import BaseModel


class User(AbstractUser):
    """
    Default custom user model for asal-azhal.
    If adding fields that need to be filled at user signup,
    check forms.SignupForm and forms.SocialSignupForms accordingly.
    """

    # First and last name do not cover name patterns around the globe
    name = CharField(_("Name of User"), blank=True, max_length=255)
    first_name = None  # type: ignore[assignment]
    last_name = None  # type: ignore[assignment]
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    user_type = models.CharField(
        choices=[
            ("student", "Student"),
            ("employee", "Staff"),
            ("school_admin", "Admin"),
            ("super_admin", "Super Admin"),
            ("guest", "Guest"),
        ],
        max_length=255,
        blank=True,
        default="student",
    )

    @property
    def role(self):
        return self.user_type

    def get_full_name(self):
        return self.name or f"{self.first_name} {self.last_name}"

    @property
    def is_employee(self):
        return self.user_type == "employee"

    @property
    def is_student(self):
        return self.user_type == "student"

    @property
    def is_school_admin(self):
        return self.user_type == "school_admin"

    @property
    def is_guest(self):
        return self.user_type == "guest"

    def __str__(self):
        return self.username

    def get_reset_password_token(self):
        import secrets

        # token =
        token = secrets.token_urlsafe(128)
        links = LoginToken.objects.filter(user=self, is_expired=False)
        if links.exists():
            link = links.first()
            token = link.token
        else:
            LoginToken.objects.create(user=self, token=token)
        return token

    def as_dict(self):
        return {
            "id": self.id,
            "username": self.username,
            "name": self.name,
            "email": self.email,
        }

    def get_absolute_url(self) -> str:
        """Get URL for user's detail view.

        Returns:
            str: URL for user detail.

        """
        return reverse("users:detail", kwargs={"username": self.username})

    def get_reset_password_token(self):
        import secrets

        # token =
        token = secrets.token_urlsafe(128)
        links = LoginToken.objects.filter(user=self, is_expired=False)
        if links.exists():
            link = links.first()
            token = link.token
        else:
            LoginToken.objects.create(user=self, token=token)
        return token

    def get_set_password_url(self):
        # FIXME: Change this to the actual site url
        site = get_current_site(None)
        site_url = site.domain
        return f"http://localhost:3000/set-password?token={self.get_reset_password_token()}"

    def send_forgot_password_email(self):
        from django.core.mail import send_mail
        from django.template.loader import render_to_string

        login_message = render_to_string(
            "users/email/forgot_password_client.html",
            {"set_password_link": self.get_set_password_url()},
        )
        send_mail(
            "AsalAzhal - Forgot Password?",
            from_email="info@asalazhal.com",
            recipient_list=[self.email],
            fail_silently=False,
            message="",
            html_message=login_message,
        )

        self.login_email_sent = True
        self.save()


class LoginToken(BaseModel):
    user = models.ForeignKey(
        "users.User", on_delete=models.CASCADE, related_name="login_tokens"
    )
    token = models.CharField(max_length=255)
    is_expired = models.BooleanField(default=False)

    def __str__(self):
        return self.token

    class Meta:
        verbose_name = "Login Token"
        verbose_name_plural = "Login Tokens"
        ordering = ["-created_at"]
