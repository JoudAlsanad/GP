from django.db import models
from django.db.models import JSONField


class BaseModel(models.Model):
    """Base model with auto updated created_at and updated_at fields."""

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True
