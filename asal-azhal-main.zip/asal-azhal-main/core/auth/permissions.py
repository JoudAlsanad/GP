import hmac
from rest_framework import permissions
from hashlib import sha256

from core.auth.sign import Hmac


class HMACPermissions(permissions.BasePermission):
    """
    Global permission check for blocked IPs.
    """

    def has_permission(self, request, view):
        hmac = Hmac()
        try:
            is_valid = hmac.validate_single_signature(request)
        except:
            is_valid = False
        return is_valid


class isOwner(permissions.BasePermission):
    """
    Global permission check for blocked IPs.
    """

    def has_object_permission(self, request, view, obj):
        if hasattr(obj, "user"):
            return obj.user == request.user
        return False


class IsEmployee(permissions.BasePermission):
    """
    Global permission check for blocked IPs.
    """

    def has_permission(self, request, view):
        return (request.user and request.user.is_employee) or request.user.is_superuser


class IsStudent(permissions.BasePermission):
    """
    Global permission check for blocked IPs.
    """

    def has_permission(self, request, view):
        return (request.user and request.user.is_student) or request.user.is_superuser


class IsStudentOrGuest(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user and (request.user.is_student or request.user.is_guest)


class IsGuest(permissions.BasePermission):
    """
    Global permission check for blocked IPs.
    """

    def has_permission(self, request, view):
        return request.user.is_guest


class IsNotGuest(permissions.BasePermission):
    """
    Custom permission to prevent guest users from accessing restricted features.
    """

    def has_permission(self, request, view):
        return not request.user.is_guest  # Restrict access for guests


class IsSchoolAdmin(permissions.BasePermission):
    """
    Global permission check for blocked IPs.
    """

    def has_permission(self, request, view):
        return (
            request.user and request.user.is_school_admin
        ) or request.user.is_superuser
