from langchain_community.chat_message_histories import ChatMessageHistory
from chat.models import ChatMessage, Conversation
from langchain_openai import ChatOpenAI, OpenAIEmbeddings


def create_conversation(user, title):
    conversation = Conversation.objects.create(user=user, title=title)
    return conversation


def save_message(conversation, role, content, ref_path=""):
    ChatMessage.objects.create(
        conversation=conversation, role=role, content=content, rag_reference=ref_path
    )


def retrieve_conversation_history(conversation, num_messages):
    recent_messages = ChatMessage.objects.filter(conversation=conversation).order_by(
        "-created_at"
    )[:num_messages][::-1]

    memory = ChatMessageHistory()
    for message in recent_messages:
        if message.role == ChatMessage.ROLE_CHOICES.USER:
            memory.add_user_message(message.content)
        elif message.role == ChatMessage.ROLE_CHOICES.AI:
            memory.add_ai_message(message.content)

    return memory


def get_conversation(conversation_uuid, user):
    try:
        # Fetch the conversation by ID and ensure it belongs to the current user
        conversation = Conversation.objects.get(uuid=conversation_uuid, user=user)
        return conversation

    except Conversation.DoesNotExist:
        raise ValueError("Incorrect ID or User")


def update_conversation_title(conversation, title):
    conversation.title = title
    conversation.save()
    return conversation


def test_openai_connection():
    try:
        llm_4 = ChatOpenAI(model="gpt-4o", temperature=0.2)
        llm_4.invoke("Test Connection")
    except Exception as e:
        return False, str(e)

    return True, "Connection Successful"
