from chat.models import ChatMessage, Conversation
from core.auth.permissions import IsEmployee, IsStudent, IsNotGuest, IsSchoolAdmin
from rest_framework.permissions import IsAuthenticated
from core.views import BaseAPIView
from rest_framework.exceptions import PermissionDenied
from .serializers import ConversationSerializer, ChatMessageSerializer

from chat.services import (
    save_message,
    retrieve_conversation_history,
)

from chat.ai import get_ai_response


class ListConversationAPIView(BaseAPIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        conversations = Conversation.objects.filter(user=request.user).order_by(
            "-created_at"
        )
        serializer = ConversationSerializer(conversations, many=True)
        return self.send_success_response(
            payload=serializer.data, message="Conversations fetched successfully"
        )


class ConversationAPIView(BaseAPIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, uuid):
        try:
            conversation = Conversation.objects.get(uuid=uuid)
        except Conversation.DoesNotExist:
            return self.send_not_found_response(message="Conversation does not exist")
        if conversation.user != request.user:
            raise PermissionDenied()
        messages = conversation.messages.all()
        messages_serializer = ChatMessageSerializer(messages, many=True)
        conversation_serializer = ConversationSerializer(conversation)
        return self.send_success_response(
            payload={
                "conversation": conversation_serializer.data,
                "messages": messages_serializer.data,
            },
            message="Single conversation fetched successfully",
        )


class LastConversationAPIView(BaseAPIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        conversation = Conversation.objects.filter(user=request.user).last()
        if not conversation:
            # create new conversation
            conversation = Conversation.objects.create(
                user=request.user, title="New Conversation"
            )
        if conversation.user != request.user:
            raise PermissionDenied()
        conv_serializer = ConversationSerializer(conversation)
        messages = conversation.messages.all().order_by("created_at")
        messages_serializer = ChatMessageSerializer(messages, many=True)
        return self.send_success_response(
            payload={
                "conversation": conv_serializer.data,
                "messages": messages_serializer.data,
            },
            message="Last conversation fetched successfully",
        )


class CreateConversationAPIView(BaseAPIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        conv = Conversation.objects.create(user=request.user, title="New Conversation")
        serializer = ConversationSerializer(conv)
        return self.send_success_response(
            payload={
                "conversation": serializer.data,
                "messages": [],
            },
            message="Conversation created successfully",
        )


class ClearConversationAPIView(BaseAPIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, uuid):
        try:
            conversation = Conversation.objects.get(uuid=uuid)
        except Conversation.DoesNotExist:
            return self.send_not_found_response(message="Conversation does not exist")
        if conversation.user != request.user:
            raise PermissionDenied()
        conversation.messages.all().delete()
        conversation.save()
        serializer = ConversationSerializer(conversation)
        return self.send_success_response(
            payload=serializer.data, message="Conversation cleared successfully"
        )


class ChatConversationAPIView(BaseAPIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, uuid):
        data = request.data
        question = data.get("question")
        if not question:
            return self.send_bad_request_response(message="Question is required")
        try:
            conversation = Conversation.objects.get(uuid=uuid)
        except Conversation.DoesNotExist:
            return self.send_not_found_response(message="Conversation does not exist")
        if conversation.user != request.user:
            return self.send_unauthorized_response(message="Unauthorized")

        # save user question
        save_message(conversation, "user", question)
        conversation_history = retrieve_conversation_history(conversation, 4)

        ai_response, rag_ref = get_ai_response(question, conversation_history)

        save_message(conversation, "ai", ai_response, rag_ref)

        conv_serializer = ConversationSerializer(conversation)
        messages = conversation.messages.all().order_by("created_at")
        messages_serializer = ChatMessageSerializer(messages, many=True)
        return self.send_success_response(
            payload={
                "conversation": conv_serializer.data,
                "messages": messages_serializer.data,
            },
            message="Last conversation fetched successfully",
        )
