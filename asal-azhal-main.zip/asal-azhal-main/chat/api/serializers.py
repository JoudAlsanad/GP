import json
from rest_framework import serializers
from chat.models import ChatMessage, Conversation


class ConversationSerializer(serializers.ModelSerializer):
    def create(self, validated_data):
        user = self.context["request"].user
        # generate a random id
        title = ""
        conversation = Conversation.objects.create(user=user, title=title)
        return conversation

    class Meta:
        model = Conversation
        fields = "__all__"


class ChatMessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChatMessage
        fields = "__all__"
