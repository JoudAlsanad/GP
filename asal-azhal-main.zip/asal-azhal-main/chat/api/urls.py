from django.urls import include
from django.urls import path
from django.urls import re_path

from .views import ConversationAPIView
from .views import CreateConversationAPIView
from .views import LastConversationAPIView
from .views import ListConversationAPIView
from .views import ClearConversationAPIView
from .views import ChatConversationAPIView

urlpatterns = [
    re_path(r"^conversations/$", ListConversationAPIView.as_view(), name="chat-list"),
    re_path(
        r"^conversations/(?P<uuid>[0-9a-fA-F-]+)/$",
        ConversationAPIView.as_view(),
        name="chat-conversation",
    ),
    # last conversation
    re_path(
        r"^conversations/last/$",
        LastConversationAPIView.as_view(),
        name="chat-last-conversation",
    ),
    # create conversation
    re_path(
        r"^conversations/create/$",
        CreateConversationAPIView.as_view(),
        name="chat-create-conversation",
    ),
    # clear conversation
    re_path(
        r"^conversations/(?P<uuid>[0-9a-fA-F-]+)/clear/$",
        ClearConversationAPIView.as_view(),
        name="chat-clear-conversation",
    ),
    re_path(
        r"^conversations/(?P<uuid>[0-9a-fA-F-]+)/chat/$",
        ChatConversationAPIView.as_view(),
        name="chat-in-conversation",
    ),
]
