from django.urls import path, include, re_path

app_name = "chat"
urlpatterns = [
    path("api/", include("chat.api.urls")),
]
