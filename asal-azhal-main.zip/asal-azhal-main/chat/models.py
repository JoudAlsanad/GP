from django.db import models
from django.utils import timezone
from core.models import BaseModel
import uuid


# Create your models here.
class Conversation(BaseModel):
    user = models.ForeignKey("users.User", on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    uuid = models.UUIDField(default=uuid.uuid4, editable=False)

    def __str__(self):
        return f"{self.user} - {self.title}"


class ChatMessage(BaseModel):
    class ROLE_CHOICES(models.TextChoices):
        USER = "user", "User"
        AI = "ai", "AI"

    conversation = models.ForeignKey(
        Conversation, on_delete=models.CASCADE, related_name="messages"
    )
    role = models.CharField(
        max_length=10, choices=ROLE_CHOICES.choices, default=ROLE_CHOICES.USER
    )
    content = models.TextField()
    rag_reference = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return f"{self.conversation} - {self.role} - {self.content}"
