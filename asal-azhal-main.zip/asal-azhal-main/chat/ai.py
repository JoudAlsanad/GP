from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
import dotenv
import asyncio
import logging
from operator import itemgetter
from langchain_openai import OpenAIEmbeddings
from langchain_google_genai import ChatGoogleGenerativeAI
from documents.services import get_vector_store

logging.basicConfig(level=logging.INFO)

# load the .env file located at the root of the project
dotenv.load_dotenv(".env")
vector_store = get_vector_store()
search_kwargs = {"k": 100}
retriever = vector_store.as_retriever(search_kwargs=search_kwargs)

# prompt
# system_prompt = """You are an assistant for question-answering tasks. Answer questions from the context provided below only. If you dont know the answer, just say so.
# Translate the answer to English as well before sending it back to the user. The answer should be detailed and contain both English and Arabic response.
# Answer in this form:
# [ARABIC]:

# [ENGLISH]:
# ....
#     \n\n
#     {context}
#     ==============
#     END OF CONTEXT
# """

system_prompt = """You are an assistant for question-answering tasks in Arabic. Give a concise and summarized answers with maximum 5 lines response from the following context only.
Output in markdown format according to arabic including arabic numerals. dont answer generic questions only greetings only answer questions that related to academics on university.
dont answer questions about making a coffee; instead user should ask relevant questions.
    \n\n
    {context}
    ==============
    END OF CONTEXT
"""

prompt = ChatPromptTemplate.from_messages(
    [
        ("system", system_prompt),
        MessagesPlaceholder(variable_name="history"),
        ("human", "{question}"),
    ]
)

# llm = ChatOpenAI(model="gpt-4o", temperature=0.2)

# Gemini
llm = ChatGoogleGenerativeAI(
    model="gemini-1.5-flash",
    temperature=0,
    max_tokens=None,
    timeout=None,
    max_retries=2,
    # other params...
)


def print_me(msg):
    print(msg)
    return msg


def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)


def get_context(question):
    docs = retriever.invoke(question)
    pdf_path = docs[0].metadata["source"]
    docs_content = format_docs(docs)
    return docs_content, pdf_path


# For context: "context": itemgetter("question") | retriever | print_me | format_docs,

chain = (
    {
        "context": itemgetter("context"),
        "question": itemgetter("question"),
        "history": itemgetter("history"),
    }
    | prompt
    | print_me
    | llm
)

# log the connection status
logging.info("Connection to OpenAI successful")


def get_ai_response(question, chat_history):
    context, pdf_path = get_context(question)
    ai_response = chain.invoke(
        {
            "context": context,
            "question": question,
            "history": chat_history.messages,
        }
    )
    return ai_response.content, pdf_path
