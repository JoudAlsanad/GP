from django.contrib import admin
from chat.models import Conversation, ChatMessage


class MessageInline(admin.TabularInline):
    model = ChatMessage
    extra = 1  # Number of empty forms to display


@admin.register(Conversation)
class ConversationAdmin(admin.ModelAdmin):
    list_display = ("user", "title", "created_at", "updated_at")
    search_fields = ("user__username", "title")
    inlines = [MessageInline]


@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = (
        "conversation",
        "role",
        "content",
        "created_at",
        "updated_at",
        "rag_reference",
    )
    search_fields = ("conversation__title", "content")
    list_filter = ("role",)
